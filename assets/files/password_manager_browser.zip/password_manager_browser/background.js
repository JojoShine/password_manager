// 密码管理器浏览器扩展后台服务
class PasswordManagerAPI {
  constructor() {
    this.serverConfig = null;
    this.isConnected = false;
    this.lastConfigCheck = 0;
    this.configCheckInterval = 60000; // 60秒检查一次配置，降低频率
    this.connectionFailureCount = 0;
    this.maxRetryInterval = 300000; // 最大重试间隔5分钟
    
    // 启动时检查服务器连接
    this.checkServerConnection();
    
    // 智能检查服务器状态 - 根据失败次数调整检查间隔
    this.scheduleNextCheck();
  }

  // 智能调度下一次检查
  scheduleNextCheck() {
    // 根据连接失败次数调整检查间隔
    let interval = this.configCheckInterval;
    if (this.connectionFailureCount > 0) {
      interval = Math.min(
        this.configCheckInterval * Math.pow(2, this.connectionFailureCount - 1),
        this.maxRetryInterval
      );
    }
    
    console.log(`下次连接检查间隔: ${interval / 1000}秒`);
    
    setTimeout(() => {
      this.checkServerConnection().then(() => {
        this.scheduleNextCheck();
      });
    }, interval);
  }

  // 检查服务器连接
  async checkServerConnection() {
    try {
      const now = Date.now();
      if (now - this.lastConfigCheck < 30000) { // 30秒内不重复检查
        return this.isConnected;
      }
      
      this.lastConfigCheck = now;
      
      // 读取服务器配置
      const config = await this.readServerConfig();
      if (!config) {
        this.isConnected = false;
        this.connectionFailureCount++;
        console.log(`连接失败次数: ${this.connectionFailureCount}`);
        return false;
      }
      
      this.serverConfig = config;
      
      // 测试连接
      const isAlive = await this.pingServer();
      this.isConnected = isAlive;
      
      if (isAlive) {
        this.connectionFailureCount = 0; // 连接成功，重置失败计数
        console.log('连接成功，重置失败计数');
      } else {
        this.connectionFailureCount++;
        console.log(`连接失败次数: ${this.connectionFailureCount}`);
      }
      
      return this.isConnected;
    } catch (error) {
      console.error('检查服务器连接失败:', error);
      this.isConnected = false;
      this.connectionFailureCount++;
      console.log(`连接失败次数: ${this.connectionFailureCount}`);
      return false;
    }
  }

  // 读取服务器配置文件
  async readServerConfig() {
    try {
      // 并行尝试多个端口，提高连接速度
      const configPaths = this.getConfigPaths();
      console.log('尝试连接端口范围: 5000-5999');
      
      // 分批并行请求，避免一次性发送太多请求
      const batchSize = 50;
      for (let i = 0; i < configPaths.length; i += batchSize) {
        const batch = configPaths.slice(i, i + batchSize);
        console.log(`检查端口批次: ${5000 + i} - ${5000 + i + batchSize - 1}`);
        
        const promises = batch.map(async (configPath) => {
          try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 1000); // 1秒超时
            
            const response = await fetch(configPath, {
              signal: controller.signal,
              method: 'GET'
            });
            
            clearTimeout(timeoutId);
            
            if (response.ok) {
              const configText = await response.text();
              const configResponse = JSON.parse(configText);
              console.log('找到配置服务器:', configPath);
              console.log('原始配置响应:', configResponse);
              
              // 处理Flutter服务器的响应格式：{success: true, data: {...}}
              if (configResponse.success && configResponse.data) {
                console.log('解析后的配置:', configResponse.data);
                return configResponse.data;
              } else {
                console.log('配置响应格式不正确:', configResponse);
                return configResponse; // 兼容直接返回配置的情况
              }
            }
            return null;
          } catch (e) {
            return null;
          }
        });
        
        const results = await Promise.all(promises);
        const config = results.find(result => result !== null);
        
        if (config) {
          return config;
        }
      }
      
      console.log('未找到可用的配置服务器');
      return null;
    } catch (error) {
      console.error('读取服务器配置失败:', error);
      return null;
    }
  }

  // 获取配置文件路径
  getConfigPaths() {
    // 优先检查最常用的端口，然后扩展到整个范围
    const portRanges = [];
    
    // 优先端口：最常用的端口
    const priorityPorts = [5000, 5001, 5002, 5003, 5004, 5005, 5491]; // 包含当前端口
    for (const port of priorityPorts) {
      portRanges.push(`http://127.0.0.1:${port}/config`);
    }
    
    // 其余端口范围 5006-5999（跳过已检查的）
    for (let port = 5006; port < 6000; port++) {
      if (!priorityPorts.includes(port)) {
        portRanges.push(`http://127.0.0.1:${port}/config`);
      }
    }
    
    return portRanges;
  }

  // Ping服务器
  async pingServer() {
    if (!this.serverConfig) return false;
    
    try {
      console.log('正在ping服务器:', this.serverConfig.server_url + '/api/ping');
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 增加超时时间
      
      const response = await fetch(`${this.serverConfig.server_url}/api/ping`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.serverConfig.token}`,
          'Content-Type': 'application/json'
        },
        signal: controller.signal,
        mode: 'cors'  // 明确指定CORS模式
      });
      
      clearTimeout(timeoutId);
      
      console.log('Ping响应状态:', response.status);
      
      if (response.ok) {
        const data = await response.json();
        console.log('Ping响应数据:', data);
        return data.success && data.data.message === 'pong';
      }
      
      console.log('Ping响应不OK，状态:', response.status);
      return false;
    } catch (error) {
      console.error('Ping服务器失败:', error);
      console.error('错误详情:', error.name, error.message);
      return false;
    }
  }

  // 调用API
  async callAPI(endpoint, method = 'GET', data = null) {
    if (!this.isConnected) {
      await this.checkServerConnection();
      if (!this.isConnected) {
        throw new Error('无法连接到密码管理器应用');
      }
    }
    
    const url = `${this.serverConfig.server_url}${endpoint}`;
    const options = {
      method,
      headers: {
        'Authorization': `Bearer ${this.serverConfig.token}`,
        'Content-Type': 'application/json'
      }
    };
    
    if (data && (method === 'POST' || method === 'PUT')) {
      options.body = JSON.stringify(data);
    }
    
    try {
      const response = await fetch(url, options);
      const result = await response.json();
      
      if (!response.ok) {
        throw new Error(result.error || `HTTP ${response.status}`);
      }
      
      return result.data;
    } catch (error) {
      console.error('API调用失败:', error);
      // 如果是连接错误，重新检查连接状态
      if (error.name === 'TypeError' || error.message.includes('Failed to fetch')) {
        this.isConnected = false;
      }
      throw error;
    }
  }

  // 搜索密码
  async searchPasswords(query = '') {
    return this.callAPI(`/api/passwords?q=${encodeURIComponent(query)}`);
  }

  // 根据域名获取密码
  async getPasswordsByDomain(domain) {
    console.log('[API] 根据域名获取密码:', {
      domain: domain,
      url: `/api/passwords/domain?domain=${encodeURIComponent(domain)}`
    });
    
    const result = await this.callAPI(`/api/passwords/domain?domain=${encodeURIComponent(domain)}`);
    
    // 提取密码数组，后端返回格式为 { passwords: [...], domain: ..., total: ... }
    const passwords = result && result.passwords ? result.passwords : [];
    
    console.log('[API] 域名密码查询结果:', {
      domain: domain,
      foundPasswords: passwords.length,
      total: result ? result.total : 0,
      passwords: passwords.map(p => ({
        id: p.id,
        title: p.title,
        website: p.website,
        username: p.username
      }))
    });
    
    return passwords;  // 只返回密码数组
  }

  // 保存密码
  async savePassword(passwordData) {
    console.log('[API] 调用保存密码接口:', {
      endpoint: '/api/passwords',
      method: 'POST',
      hasData: !!passwordData,
      dataKeys: passwordData ? Object.keys(passwordData) : [],
      data: passwordData
    });
    
    try {
      const result = await this.callAPI('/api/passwords', 'POST', passwordData);
      console.log('[API] 保存密码接口响应:', result);
      return result;
    } catch (error) {
      console.error('[API] 保存密码接口失败:', error);
      throw error;
    }
  }

  // 更新密码
  async updatePassword(passwordData) {
    return this.callAPI('/api/passwords', 'PUT', passwordData);
  }

  // 删除密码
  async deletePassword(id) {
    return this.callAPI(`/api/passwords?id=${id}`, 'DELETE');
  }
}

// 创建API实例
const passwordManagerAPI = new PasswordManagerAPI();

// 监听来自content script和popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  handleMessage(request, sender, sendResponse);
  return true; // 保持消息通道开放以支持异步响应
});

// 处理消息
async function handleMessage(request, sender, sendResponse) {
  try {
    const { action, data } = request;
    let result;

    switch (action) {
      case 'checkConnection':
        result = await passwordManagerAPI.checkServerConnection();
        break;

      case 'searchPasswords':
        result = await passwordManagerAPI.searchPasswords(data.query);
        break;

      case 'getPasswordsByDomain':
        result = await passwordManagerAPI.getPasswordsByDomain(data.domain);
        
        // 更新当前标签页的图标状态
        try {
          if (sender && sender.tab && sender.tab.id) {
            if (result && result.length > 0) {
              await updateExtensionBadge(sender.tab.id, result.length);
            } else {
              await clearExtensionBadge(sender.tab.id);
            }
          }
        } catch (error) {
          console.error('更新图标状态失败:', error);
        }
        break;

      case 'savePassword':
        console.log('[BACKGROUND] 接收到保存密码请求:', {
          hasPasswordData: !!data.password,
          passwordFields: data.password ? Object.keys(data.password) : [],
          passwordData: data.password
        });
        try {
          result = await passwordManagerAPI.savePassword(data.password);
          console.log('[BACKGROUND] 保存密码成功:', result);
          
          // 保存成功后，更新当前标签页的图标状态
          if (sender && sender.tab && sender.tab.id && data.password && data.password.website) {
            const domain = extractDomain(data.password.website);
            if (domain) {
              const updatedPasswords = await passwordManagerAPI.getPasswordsByDomain(domain);
              if (updatedPasswords && updatedPasswords.length > 0) {
                await updateExtensionBadge(sender.tab.id, updatedPasswords.length);
              }
            }
          }
        } catch (error) {
          console.error('[BACKGROUND] 保存密码失败:', error);
          throw error; // 重新抛出错误以便外层处理
        }
        break;

      case 'updatePassword':
        result = await passwordManagerAPI.updatePassword(data.password);
        break;

      case 'deletePassword':
        result = await passwordManagerAPI.deletePassword(data.id);
        break;

      case 'getConnectionStatus':
        result = {
          isConnected: passwordManagerAPI.isConnected,
          serverUrl: passwordManagerAPI.serverConfig ? passwordManagerAPI.serverConfig.server_url : null
        };
        break;

      default:
        throw new Error(`未知操作: ${action}`);
    }

    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('处理消息失败:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// 提取域名工具函数
function extractDomain(url) {
  try {
    if (!url) return null;
    
    let cleanUrl = url.trim();
    
    // 如果不是完整URL，尝试添加协议
    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      // 检查是否是IP地址
      const ipRegex = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?$/;
      if (ipRegex.test(cleanUrl)) {
        return cleanUrl.split(':')[0]; // 移除端口号，只返回IP地址
      }
      cleanUrl = 'https://' + cleanUrl;
    }
    
    const urlObj = new URL(cleanUrl);
    return urlObj.hostname.toLowerCase();
  } catch (error) {
    // 如果URL解析失败，尝试直接提取域名或IP
    let cleanUrl = url ? url.trim() : '';
    
    // 移除协议和路径，只保留域名/IP
    cleanUrl = cleanUrl.replace(/^https?:\/\//, '').split('/')[0].split('?')[0];
    
    // 移除端口号
    cleanUrl = cleanUrl.split(':')[0];
    
    // 检查是否是IP地址
    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (ipRegex.test(cleanUrl)) {
      return cleanUrl;
    }
    
    // 检查是否是有效域名
    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*\.([a-zA-Z]{2,}|[a-zA-Z0-9-]*[a-zA-Z0-9])$/;
    if (domainRegex.test(cleanUrl)) {
      return cleanUrl.toLowerCase();
    }
    
    return cleanUrl.toLowerCase(); // 返回处理后的字符串，即使不是标准域名
  }
}

// 智能匹配密码算法
function smartMatchPasswords(passwords, currentDomain, currentIP, currentURL) {
  const matchedPasswords = passwords.map(password => {
    const matchResult = calculateMatchScore(password, currentDomain, currentIP, currentURL);
    return {
      ...password,
      matchScore: matchResult.score,
      matchType: matchResult.type,
      matchReason: matchResult.reason
    };
  });

  // 按匹配分数排序，分数高的在前
  return matchedPasswords.sort((a, b) => b.matchScore - a.matchScore);
}

// 计算匹配分数
function calculateMatchScore(password, currentDomain, currentIP, currentURL) {
  if (!password.website) {
    return { score: 0, type: 'none', reason: '无网站信息' };
  }

  const passwordDomain = extractDomain(password.website);
  
  // 完全域名匹配 - 包括IP地址匹配
  if (passwordDomain && currentDomain && passwordDomain === currentDomain) {
    const isIP = /^(\d{1,3}\.){3}\d{1,3}$/.test(currentDomain);
    return { score: 100, type: 'exact', reason: isIP ? 'IP地址完全匹配' : '域名完全匹配' };
  }

  // 子域名匹配
  if (passwordDomain && currentDomain) {
    const passwordParts = passwordDomain.split('.').reverse();
    const currentParts = currentDomain.split('.').reverse();
    
    let matchedParts = 0;
    const minLength = Math.min(passwordParts.length, currentParts.length);
    
    for (let i = 0; i < minLength; i++) {
      if (passwordParts[i] === currentParts[i]) {
        matchedParts++;
      } else {
        break;
      }
    }

    if (matchedParts >= 2) { // 至少匹配顶级域名和二级域名
      const score = 80 - (Math.abs(passwordParts.length - currentParts.length) * 5);
      return { score: Math.max(score, 60), type: 'partial', reason: '子域名匹配' };
    }
  }

  // URL包含匹配
  if (currentURL && password.website) {
    const normalizedPasswordWebsite = password.website.toLowerCase();
    const normalizedCurrentURL = currentURL.toLowerCase();
    
    if (normalizedCurrentURL.includes(normalizedPasswordWebsite) || 
        normalizedPasswordWebsite.includes(normalizedCurrentURL)) {
      return { score: 50, type: 'partial', reason: 'URL包含匹配' };
    }
  }

  // 关键词匹配
  if (password.title && currentDomain) {
    const titleLower = password.title.toLowerCase();
    const domainParts = currentDomain.split('.');
    
    for (const part of domainParts) {
      if (part.length > 3 && titleLower.includes(part)) {
        return { score: 30, type: 'partial', reason: '标题关键词匹配' };
      }
    }
  }

  return { score: 0, type: 'none', reason: '无匹配' };
}

// 标签页处理缓存，避免频繁检查同一个域名
const tabDomainCache = new Map();

// 更新扩展图标标记
async function updateExtensionBadge(tabId, passwordCount) {
  try {
    // 设置标记文本 - 显示密码数量
    await chrome.action.setBadgeText({
      text: passwordCount.toString(),
      tabId: tabId
    });
    
    // 设置标记背景色 - 绿色表示有密码
    await chrome.action.setBadgeBackgroundColor({
      color: '#34a853', // 谷歌绿色
      tabId: tabId
    });
    
    // 设置标记文字颜色为白色
    await chrome.action.setBadgeTextColor({
      color: '#ffffff',
      tabId: tabId
    });
    
    console.log(`已为标签页 ${tabId} 设置密码数量标记: ${passwordCount}`);
  } catch (error) {
    console.error('更新扩展图标标记失败:', error);
  }
}

// 清除扩展图标标记
async function clearExtensionBadge(tabId) {
  try {
    await chrome.action.setBadgeText({
      text: '',
      tabId: tabId
    });
    
    console.log(`已清除标签页 ${tabId} 的密码标记`);
  } catch (error) {
    console.error('清除扩展图标标记失败:', error);
  }
}

// 监听标签页更新，为活动标签页预加载密码数据
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  // 仅在页面完全加载完成且是HTTP/HTTPS页面时处理
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    const domain = extractDomain(tab.url);
    if (domain) {
      // 检查缓存，避免重复检查同一域名
      const cacheKey = `${tabId}-${domain}`;
      const lastCheck = tabDomainCache.get(cacheKey);
      const now = Date.now();
      
      // 30秒内不重复检查同一个标签页的同一个域名
      if (lastCheck && (now - lastCheck) < 30000) {
        console.log(`跳过重复检查域名: ${domain}`);
        return;
      }
      
      tabDomainCache.set(cacheKey, now);
      console.log(`标签页 ${tabId} 导航至域名: ${domain}`);
      
      try {
        // 静默预加载密码数据，不打扰用户
        const passwords = await passwordManagerAPI.getPasswordsByDomain(domain);
        
        if (passwords && passwords.length > 0) {
          console.log(`域名 ${domain} 预加载 ${passwords.length} 个密码`);
          
          // 更新扩展图标显示密码数量
          await updateExtensionBadge(tabId, passwords.length);
          
          // 静默缓存密码数据，仅在用户打开弹窗时显示
          // 不发送通知到content script，减少页面干扰
        } else {
          console.log(`域名 ${domain} 没有匹配的密码`);
          
          // 清除扩展图标标记
          await clearExtensionBadge(tabId);
        }
      } catch (error) {
        // 静默处理错误，不影响用户体验
        console.error(`预加载域名 ${domain} 密码失败:`, error);
      }
    }
  }
});

// 监听标签页激活，更新对应标签页的图标状态
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && tab.url.startsWith('http')) {
      const domain = extractDomain(tab.url);
      if (domain) {
        // 检查该域名的密码数量并更新图标
        const passwords = await passwordManagerAPI.getPasswordsByDomain(domain);
        if (passwords && passwords.length > 0) {
          await updateExtensionBadge(activeInfo.tabId, passwords.length);
        } else {
          await clearExtensionBadge(activeInfo.tabId);
        }
      }
    }
  } catch (error) {
    console.error('标签页激活时更新图标失败:', error);
  }
});

// 清理标签页缓存
chrome.tabs.onRemoved.addListener((tabId) => {
  // 清理该标签页的所有缓存
  for (const [key, value] of tabDomainCache.entries()) {
    if (key.startsWith(`${tabId}-`)) {
      tabDomainCache.delete(key);
    }
  }
});

// 启动时初始化当前活动标签页的图标状态
chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
  if (tabs.length > 0) {
    const tab = tabs[0];
    if (tab.url && tab.url.startsWith('http')) {
      const domain = extractDomain(tab.url);
      if (domain && passwordManagerAPI.isConnected) {
        try {
          const passwords = await passwordManagerAPI.getPasswordsByDomain(domain);
          if (passwords && passwords.length > 0) {
            await updateExtensionBadge(tab.id, passwords.length);
          } else {
            await clearExtensionBadge(tab.id);
          }
        } catch (error) {
          console.error('初始化图标状态失败:', error);
        }
      }
    }
  }
});

console.log('密码管理器浏览器扩展后台服务已启动'); 