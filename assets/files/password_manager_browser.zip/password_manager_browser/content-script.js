// 密码管理器内容脚本
(function() {
  'use strict';
  
  // 配置常量
  const CONFIG = {
    AUTO_FILL_DELAY: 1000,
    SAVE_PROMPT_DELAY: 2000,
    FORM_MONITOR_INTERVAL: 500,
    MAX_RETRY_COUNT: 3
  };
  
  // 状态管理
  let formMonitor = null;
  let currentDomain = window.location.hostname.toLowerCase();
  let availablePasswords = [];
  let hasTriedAutoFill = false;
  let savePromptShown = false;
  
  // DOM元素缓存
  let loginForm = null;
  let usernameField = null;
  let passwordField = null;
  
  // 全局错误处理
  window.addEventListener('error', (event) => {
    if (event.error && event.error.message) {
      if (event.error.message.includes('Extension context invalidated') ||
          event.error.message.includes('Could not establish connection')) {
        console.warn('检测到扩展连接错误，已自动处理');
        // 静默处理，不显示错误通知以免干扰用户
      } else if (event.error.message.includes('appendChild') || 
                 event.error.message.includes('parameter 1 is not of type')) {
        console.error('DOM操作错误:', {
          message: event.error.message,
          stack: event.error.stack,
          filename: event.filename,
          lineno: event.lineno,
          colno: event.colno
        });
        showNotification('页面操作失败，请刷新页面重试', 'error');
        // 重置状态
        savePromptShown = false;
      }
    }
  });

  // 初始化
  function initialize() {
    console.log('🎯 [CONTENT] Password Manager Content Script 已加载');
    console.log('🌐 [CONTENT] 当前页面:', {
      url: window.location.href,
      title: document.title,
      domain: window.location.hostname
    });
    
    // 开始监控表单
    startFormMonitoring();
    
    // 监听来自后台脚本的消息
    chrome.runtime.onMessage.addListener(handleMessage);
    
    // 监听页面变化
    observePageChanges();
  }
  
  // 处理来自后台脚本的消息
  function handleMessage(request, sender, sendResponse) {
    console.log('📩 [CONTENT] 收到消息:', request);
    
    const { action, data } = request;
    
    switch (action) {
      case 'domainPasswordsAvailable':
        handleDomainPasswords(data);
        sendResponse({ success: true });
        break;
      
      case 'fillPassword':
        console.log('🔐 [CONTENT] 开始执行密码填充');
        
        // 异步处理填充
        attemptPasswordFill(data.password)
          .then(result => {
            console.log('✅ [CONTENT] 填充完成，发送响应:', result);
            sendResponse(result);
          })
          .catch(error => {
            console.error('❌ [CONTENT] 填充失败:', error);
            const errorResult = {
              success: false,
              message: `填充失败: ${error.message}`,
              error: error.message
            };
            sendResponse(errorResult);
          });
        break;
        
      default:
        console.log('❓ [CONTENT] 未知消息:', action);
        sendResponse({ success: false, error: '未知操作' });
    }
    
    return true; // 保持消息通道开放以支持异步响应
  }
  
  // 处理域名密码数据
  function handleDomainPasswords(data) {
    console.log('🔍 处理域名密码数据:', {
      requestedDomain: data.domain,
      currentDomain: currentDomain,
      domainsMatch: data.domain === currentDomain,
      receivedPasswords: data.passwords ? data.passwords.length : 0,
      passwordData: data.passwords || []
    });
    
    if (data.domain === currentDomain) {
      const previousCount = availablePasswords.length;
      availablePasswords = data.passwords || [];
      
      console.log('✅ 域名匹配，更新可用密码:', {
        previousCount: previousCount,
        newCount: availablePasswords.length,
        passwords: availablePasswords.map(p => ({
          id: p.id,
          title: p.title,
          username: p.username,
          website: p.website
        }))
      });
      
      if (data.hasPasswords && !hasTriedAutoFill) {
        console.log('🚀 启动自动填充延迟任务');
        // 延迟自动填充，确保页面完全加载
        setTimeout(() => {
          attemptAutoFill();
        }, CONFIG.AUTO_FILL_DELAY);
      }
    } else {
      console.log('❌ 域名不匹配，跳过处理');
    }
  }
  
  // 开始表单监控
  function startFormMonitoring() {
    if (formMonitor) return;
    
    formMonitor = setInterval(() => {
      detectAndAnalyzeForms();
    }, CONFIG.FORM_MONITOR_INTERVAL);
    
    // 立即执行一次
    detectAndAnalyzeForms();
  }
  
  // 停止表单监控
  function stopFormMonitoring() {
    if (formMonitor) {
      clearInterval(formMonitor);
      formMonitor = null;
    }
  }
  
  // 检测和分析表单
  function detectAndAnalyzeForms() {
    const forms = document.querySelectorAll('form');
    
    for (const form of forms) {
      const analysis = analyzeForm(form);
      
      if (analysis.isLoginForm) {
        if (loginForm !== form) {
          loginForm = form;
          usernameField = analysis.usernameField;
          passwordField = analysis.passwordField;
          
          console.log('检测到登录表单');
          setupFormListeners();
          
          // 如果有可用密码，尝试自动填充
          if (availablePasswords.length > 0 && !hasTriedAutoFill) {
            setTimeout(() => attemptAutoFill(), CONFIG.AUTO_FILL_DELAY);
          }
        }
        return; // 找到登录表单就停止搜索
      }
    }
  }
  
  // 分析表单类型
  function analyzeForm(form) {
    const inputs = form.querySelectorAll('input');
    let usernameField = null;
    let passwordField = null;
    let isLoginForm = false;
    
    // 查找密码字段
    for (const input of inputs) {
      if (input.type === 'password') {
        passwordField = input;
        break;
      }
    }
    
    if (!passwordField) return { isLoginForm: false };
    
    // 查找用户名字段
    for (const input of inputs) {
      if (input.type === 'text' || input.type === 'email') {
        const fieldAnalysis = analyzeUsernameField(input);
        if (fieldAnalysis.isUsernameField) {
          usernameField = input;
          break;
        }
      }
    }
    
    // 确定是否为登录表单
    if (passwordField) {
      isLoginForm = true;
      
      // 更精确的判断
      const formText = form.textContent.toLowerCase();
      const hasLoginKeywords = /login|sign.?in|log.?in|登录|登入/.test(formText);
      const hasRegisterKeywords = /register|sign.?up|create|join|注册|创建/.test(formText);
      
      if (hasRegisterKeywords && !hasLoginKeywords) {
        isLoginForm = false;
      }
    }
    
    return {
      isLoginForm,
      usernameField,
      passwordField,
      form
    };
  }
  
  // 分析用户名字段
  function analyzeUsernameField(input) {
    const name = (input.name || '').toLowerCase();
    const id = (input.id || '').toLowerCase();
    const placeholder = (input.placeholder || '').toLowerCase();
    const label = getFieldLabel(input);
    
    const usernamePatterns = [
      'username', 'user', 'email', 'login', 'account',
      '用户名', '邮箱', '账号', '手机', 'phone'
    ];
    
    const allText = `${name} ${id} ${placeholder} ${label}`.toLowerCase();
    
    const isUsernameField = usernamePatterns.some(pattern => 
      allText.includes(pattern)
    );
    
    return { isUsernameField };
  }
  
  // 获取字段标签
  function getFieldLabel(input) {
    // 查找关联的label
    let label = '';
    
    if (input.id) {
      const labelElement = document.querySelector(`label[for="${input.id}"]`);
      if (labelElement) {
        label = labelElement.textContent || '';
      }
    }
    
    // 查找父级元素中的label
    if (!label) {
      const parent = input.parentElement;
      if (parent) {
        const labelElement = parent.querySelector('label');
        if (labelElement) {
          label = labelElement.textContent || '';
        }
      }
    }
    
    return label;
  }
  
  // 设置表单监听器
  function setupFormListeners() {
    if (!loginForm) return;
    
    // 监听表单提交
    loginForm.addEventListener('submit', handleFormSubmit);
    
    // 监听密码字段变化
    if (passwordField) {
      passwordField.addEventListener('input', handlePasswordInput);
    }
    
    // 添加自动填充按钮
    addAutoFillButton();
  }
  
  // 处理表单提交
  function handleFormSubmit(event) {
    console.log('📤 表单提交事件', {
      savePromptShown: savePromptShown,
      hasPasswordField: !!passwordField,
      passwordValue: passwordField ? passwordField.value : '',
      hasUsernameField: !!usernameField,
      usernameValue: usernameField ? usernameField.value : ''
    });
    
    if (!savePromptShown && passwordField && passwordField.value) {
      console.log('⏰ 延迟调用 prepareSavePrompt');
      setTimeout(() => {
        prepareSavePrompt();
      }, CONFIG.SAVE_PROMPT_DELAY);
    } else {
      console.log('❌ 跳过保存提示，原因:', {
        savePromptShown: savePromptShown,
        hasPasswordField: !!passwordField,
        hasPasswordValue: passwordField ? !!passwordField.value : false
      });
    }
  }
  
  // 处理密码输入
  function handlePasswordInput(event) {
    const password = event.target.value;
    if (password && password.length > 3) {
      // 延迟显示保存提示，避免输入过程中频繁触发
      setTimeout(() => {
        if (event.target.value === password) { // 确保值没有变化
          prepareSavePrompt();
        }
      }, 1000);
    }
  }
  
  // 准备保存提示
  function prepareSavePrompt() {
    console.log('🔍 prepareSavePrompt 被调用');
    
    if (savePromptShown) {
      console.log('❌ 保存提示已显示，跳过');
      return;
    }
    
    const username = usernameField ? usernameField.value.trim() : '';
    const password = passwordField ? passwordField.value : '';
    
    console.log('📝 表单信息检查:', {
      hasUsernameField: !!usernameField,
      hasPasswordField: !!passwordField,
      username: username,
      passwordLength: password ? password.length : 0,
      currentDomain: currentDomain,
      availablePasswordsCount: availablePasswords.length
    });
    
    if (!username) {
      console.log('❌ 用户名为空，跳过保存');
      return;
    }
    
    if (!password) {
      console.log('❌ 密码为空，跳过保存');
      return;
    }
    
    if (password.length < 4) {
      console.log('❌ 密码长度不足4位，跳过保存');
      return;
    }
    
    // 检查是否已存在相同的密码
    const existingPassword = availablePasswords.find(p => 
      (p.username === username || p.email === username) && 
      p.website && p.website.includes(currentDomain)
    );
    
    if (!existingPassword) {
      console.log('✅ 满足保存条件，准备显示保存提示:', { username, domain: currentDomain });
      showSavePrompt();
    } else {
      console.log('❌ 密码已存在，跳过保存提示:', existingPassword);
    }
  }
  
  // 检测页面限制
  function detectPageRestrictions() {
    const restrictions = [];
    
    // 检查CSP
    const metaTags = document.querySelectorAll('meta[http-equiv="Content-Security-Policy"]');
    if (metaTags.length > 0) {
      restrictions.push('CSP策略限制');
    }
    
    // 检查body是否被替换
    if (!document.body || typeof document.body.appendChild !== 'function') {
      restrictions.push('document.body不可用');
    }
    
    // 检查是否在iframe中
    if (window !== window.top) {
      restrictions.push('页面在iframe中');
    }
    
    // 检查常见的SPA框架
    if (window.React || window.Vue || window.Angular) {
      restrictions.push('检测到前端框架');
    }
    
    console.log('页面限制检测结果:', restrictions);
    return restrictions;
  }

  // 显示保存密码提示
  function showSavePrompt() {
    console.log('🎯 showSavePrompt 被调用');
    
    if (savePromptShown) {
      console.log('❌ savePromptShown = true，跳过');
      return;
    }
    
    try {
      const username = usernameField ? usernameField.value : '';
      const password = passwordField ? passwordField.value : '';
      
      console.log('🔍 showSavePrompt 检查:', {
        username: username,
        passwordLength: password ? password.length : 0,
        hasUsername: !!username,
        hasPassword: !!password
      });
      
      if (!username || !password) {
        console.log('❌ 用户名或密码为空，跳过保存提示');
        return;
      }
      
      // 检测页面限制
      const restrictions = detectPageRestrictions();
      if (restrictions.length > 0) {
        console.warn('检测到页面限制:', restrictions);
      }
      
      savePromptShown = true;
      
      const result = createSavePrompt(username, password);
    
    // 安全检查，确保返回值正确
    if (!result || !result.promptDiv || !result.overlay) {
      console.error('createSavePrompt 返回无效结果:', result);
      showNotification('保存密码提示框创建失败', 'error');
      savePromptShown = false;
      return;
    }
    
    let { promptDiv, overlay } = result;
    
    // 再次检查元素是否为有效的 DOM 节点
    if (!(overlay instanceof Node) || !(promptDiv instanceof Node)) {
      console.error('创建的元素不是有效的DOM节点:', { 
        overlay: overlay, 
        promptDiv: promptDiv,
        overlayType: typeof overlay,
        promptDivType: typeof promptDiv,
        overlayIsNode: overlay instanceof Node,
        promptDivIsNode: promptDiv instanceof Node
      });
      showNotification('保存密码提示框创建失败', 'error');
      savePromptShown = false;
      return;
    }
    
    // 额外检查：确保元素没有已经被添加到DOM中
    if (overlay.parentNode || promptDiv.parentNode) {
      console.warn('元素已经在DOM中，先移除旧元素');
      if (overlay.parentNode) overlay.remove();
      if (promptDiv.parentNode) promptDiv.remove();
    }
    
    // 确保 document.body 存在
    if (!document.body) {
      console.error('document.body 不存在，无法添加保存提示框');
      showNotification('页面未完全加载，无法显示保存提示', 'error');
      savePromptShown = false;
      return;
    }
    
    try {
      // 使用更安全的方式添加元素，绕过可能的页面限制
      console.log('尝试添加元素到页面...');
      
      // 方法1：尝试直接添加到body（只添加div，不需要overlay）
      if (document.body && typeof document.body.appendChild === 'function') {
        try {
          document.body.appendChild(promptDiv);
          console.log('保存密码提示框已成功添加到页面 (方法1: body)');
          console.log('提示框样式检查:', {
            id: promptDiv.id,
            position: promptDiv.style.position,
            top: promptDiv.style.top,
            right: promptDiv.style.right,
            zIndex: promptDiv.style.zIndex,
            opacity: promptDiv.style.opacity,
            transform: promptDiv.style.transform,
            display: window.getComputedStyle(promptDiv).display,
            visibility: window.getComputedStyle(promptDiv).visibility
          });
        } catch (bodyError) {
          console.warn('添加到body失败，尝试其他方法:', bodyError);
          throw bodyError;
        }
      } else {
        throw new Error('document.body 不可用');
      }
    } catch (appendError) {
      console.error('方法1失败，尝试备用方案:', appendError);
      
      try {
        // 方法2：尝试添加到documentElement
        if (document.documentElement) {
          document.documentElement.appendChild(promptDiv);
          console.log('保存密码提示框已成功添加到页面 (方法2: documentElement)');
        } else {
          throw new Error('document.documentElement 不可用');
        }
      } catch (docElementError) {
        console.error('方法2也失败，尝试最后方案:', docElementError);
        
        try {
          // 方法3：使用insertAdjacentHTML作为最后手段
          const promptHTML = promptDiv.outerHTML;
          
          if (document.body) {
            document.body.insertAdjacentHTML('beforeend', promptHTML);
            console.log('保存密码提示框已成功添加到页面 (方法3: insertAdjacentHTML)');
            
            // 重新获取元素引用以便后续操作
            const insertedPrompt = document.getElementById('password-manager-save-prompt');
            
            if (insertedPrompt) {
              // 更新引用
              promptDiv = insertedPrompt;
            }
          } else {
            throw new Error('所有方法都失败');
          }
                 } catch (finalError) {
           console.error('所有添加方法都失败:', finalError);
           
           // 最后的备用方案：使用原生确认框
           const shouldSave = confirm(`密码管理器检测到登录信息：\n用户名：${username}\n\n是否保存此密码？`);
           if (shouldSave) {
             console.log('用户确认保存，使用原生对话框方案');
             savePassword(username, password)
               .then(() => {
                 alert('密码保存成功！');
               })
               .catch(error => {
                 alert('密码保存失败：' + error.message);
               });
           }
           
           savePromptShown = false;
           return;
         }
      }
    }
    
    // 延长显示时间，添加重新唤醒机制
    setTimeout(() => {
      if (promptDiv && promptDiv.parentNode) {
        promptDiv.remove();
      }
      // 延迟重置状态，允许重新触发
      setTimeout(() => {
        savePromptShown = false;
      }, 30000); // 30秒后允许重新显示
    }, 20000); // 显示20秒
    } catch (error) {
      console.error('显示保存密码提示失败:', error);
      savePromptShown = false;
      showNotification('保存密码提示显示失败', 'error');
    }
  }
  
  // 安全地发送扩展消息的函数
  async function safeSendMessage(message, maxRetries = 2) {
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        // 检查扩展上下文是否有效
        if (!chrome.runtime || !chrome.runtime.id) {
          throw new Error('扩展上下文无效');
        }
        
        const response = await chrome.runtime.sendMessage(message);
        
        // 如果收到正常响应，返回结果
        if (response !== undefined) {
          return response;
        }
        
        throw new Error('收到空响应');
      } catch (error) {
        console.warn(`发送消息失败 (尝试 ${attempt + 1}/${maxRetries + 1}):`, error.message);
        
        if (error.message.includes('Extension context invalidated') || 
            error.message.includes('Could not establish connection') ||
            error.message.includes('扩展上下文无效')) {
          
          if (attempt < maxRetries) {
            console.log('检测到扩展连接问题，等待后重试...');
            await new Promise(resolve => setTimeout(resolve, 1000 * (attempt + 1)));
            continue;
          } else {
            // 最后一次尝试失败，给用户友好的提示
            throw new Error('扩展连接已断开，请刷新页面或重新加载扩展');
          }
        } else {
          // 其他类型的错误，直接抛出
          throw error;
        }
      }
    }
  }

  // 密码强度评估函数
  function evaluatePasswordStrength(password) {
    if (!password) return { score: 0, text: '无密码', color: '#ea4335' };
    
    let score = 0;
    const length = password.length;
    
    // 长度评分
    if (length >= 8) score += 25;
    if (length >= 12) score += 15;
    if (length >= 16) score += 10;
    
    // 包含数字
    if (/\d/.test(password)) score += 15;
    
    // 包含小写字母
    if (/[a-z]/.test(password)) score += 15;
    
    // 包含大写字母
    if (/[A-Z]/.test(password)) score += 15;
    
    // 包含特殊字符
    if (/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~`]/.test(password)) score += 15;
    
    // 评分转换为等级
    if (score >= 80) return { score, text: '强', color: '#34a853' };
    if (score >= 60) return { score, text: '中等', color: '#fbbc04' };
    if (score >= 40) return { score, text: '较弱', color: '#ff9800' };
    return { score, text: '弱', color: '#ea4335' };
  }

  // 创建保存提示界面
  function createSavePrompt(username, password) {
    try {
      console.log('创建保存密码提示框:', { username, passwordLength: password ? password.length : 0 });
      
      // 验证参数
      if (!username || !password) {
        console.error('createSavePrompt 参数无效:', { username, password });
        return null;
      }
      
      // 创建背景遮罩
      const overlay = document.createElement('div');
      overlay.id = 'password-manager-overlay';
      
      // 验证元素创建是否成功
      if (!overlay || !(overlay instanceof HTMLElement)) {
        console.error('创建遮罩元素失败');
        return null;
      }
    // 创建简洁的通知容器
    overlay.style.cssText = `
      position: fixed;
      top: 16px;
      right: 16px;
      z-index: 10000;
      pointer-events: none;
    `;
    
    const div = document.createElement('div');
    div.id = 'password-manager-save-prompt';
    
    // 验证元素创建是否成功
    if (!div || !(div instanceof HTMLElement)) {
      console.error('创建提示框元素失败');
      return null;
    }
    
    // 获取当前页面信息
    const pageTitle = document.title || '未知页面';
    const currentUrl = window.location.href;
    const protocol = window.location.protocol;
    const isSecure = protocol === 'https:';
    
    div.style.cssText = `
      position: fixed;
      top: 16px;
      right: 16px;
      background: #ffffff;
      border: 1px solid #dadce0;
      border-radius: 8px;
      padding: 16px;
      box-shadow: 0 4px 16px rgba(0,0,0,0.12);
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 13px;
      width: 320px;
      max-width: calc(100vw - 32px);
      line-height: 1.4;
      pointer-events: auto;
      z-index: 10001;
      opacity: 1;
      transform: translateY(0);
      transition: all 0.3s ease-out;
    `;
    
        div.innerHTML = `
      <!-- 头部区域 -->
      <div style="display: flex; align-items: center; margin-bottom: 16px; padding-bottom: 12px; border-bottom: 1px solid #e8eaed;">
        <div style="width: 32px; height: 32px; background: linear-gradient(135deg, #4285f4, #34a853); border-radius: 8px; margin-right: 12px; display: flex; align-items: center; justify-content: center; box-shadow: 0 2px 8px rgba(66,133,244,0.3);">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
            <path d="M18,8A6,6 0 0,0 12,2A6,6 0 0,0 6,8H4A2,2 0 0,0 2,10V20A2,2 0 0,0 4,22H20A2,2 0 0,0 22,20V10A2,2 0 0,0 20,8H18M12,4A4,4 0 0,1 16,8H8A4,4 0 0,1 12,4Z"/>
          </svg>
        </div>
        <div style="flex: 1;">
          <div style="font-weight: 600; color: #202124; font-size: 15px; margin-bottom: 2px;">密码管理器</div>
          <div style="color: #5f6368; font-size: 12px; display: flex; align-items: center;">
            <span style="margin-right: 6px;">🔐</span>
            <span>检测到新的登录信息</span>
          </div>
        </div>
        <button id="pm-close-btn" style="background: none; border: none; font-size: 18px; cursor: pointer; color: #5f6368; width: 28px; height: 28px; border-radius: 6px; display: flex; align-items: center; justify-content: center; transition: background-color 0.2s;">×</button>
      </div>
      
      <!-- 网站信息 -->
      <div style="background: #f8f9fa; border-radius: 8px; padding: 12px; margin-bottom: 16px; border-left: 3px solid #4285f4;">
        <div style="display: flex; align-items: center; margin-bottom: 8px;">
          <div style="width: 16px; height: 16px; background: ${isSecure ? '#34a853' : '#ea4335'}; border-radius: 50%; margin-right: 8px; display: flex; align-items: center; justify-content: center;">
            <div style="width: 6px; height: 6px; background: white; border-radius: 50%;"></div>
          </div>
          <span style="font-weight: 500; color: #202124; font-size: 13px;">${pageTitle}</span>
        </div>
        <div style="color: #5f6368; font-size: 12px; line-height: 1.3;">
          <div style="margin-bottom: 4px;">
            <strong>网站：</strong> ${currentDomain}
          </div>
          <div style="margin-bottom: 4px;">
            <strong>用户名：</strong> <span style="font-family: monospace; background: #e8f0fe; padding: 1px 4px; border-radius: 3px;">${username}</span>
          </div>
          <div>
            <strong>连接：</strong> <span style="color: ${isSecure ? '#34a853' : '#ea4335'};">${isSecure ? 'HTTPS 安全连接' : 'HTTP 不安全连接'}</span>
          </div>
        </div>
      </div>
      
      <!-- 操作提示 -->
      <div style="background: #e8f5e8; border-radius: 6px; padding: 10px; margin-bottom: 16px; border: 1px solid #c8e6c9;">
        <div style="display: flex; align-items: center; color: #2e7d32; font-size: 12px;">
          <span style="margin-right: 6px;">💡</span>
          <span>密码将安全保存在本地，不会上传到任何服务器</span>
        </div>
      </div>
      
      <!-- 按钮区域 -->
      <div style="display: flex; gap: 10px;">
        <button id="pm-cancel-btn" style="
          background: #ffffff;
          border: 1px solid #dadce0;
          color: #5f6368;
          padding: 10px 16px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 13px;
          font-family: inherit;
          flex: 1;
          font-weight: 500;
          transition: all 0.2s ease;
        ">稍后提醒</button>
        <button id="pm-save-btn" style="
          background: linear-gradient(135deg, #4285f4, #34a853);
          border: none;
          color: white;
          padding: 10px 16px;
          border-radius: 6px;
          cursor: pointer;
          font-size: 13px;
          font-family: inherit;
          flex: 2;
          font-weight: 600;
          box-shadow: 0 2px 8px rgba(66,133,244,0.3);
          transition: all 0.2s ease;
        ">立即保存密码</button>
      </div>
      
      <!-- 底部品牌信息 -->
      <div style="margin-top: 12px; padding-top: 10px; border-top: 1px solid #e8eaed; text-align: center;">
        <div style="color: #9aa0a6; font-size: 11px; display: flex; align-items: center; justify-content: center;">
          <span style="margin-right: 4px;">⚡</span>
          <span>由密码管理器浏览器扩展提供支持</span>
        </div>
      </div>
    `;
    
    // 设置初始动画（从上方滑入）
    div.style.transform = 'translateY(-20px)';
    div.style.opacity = '0';
    
    setTimeout(() => {
      div.style.opacity = '1';
      div.style.transform = 'translateY(0)';
    }, 10);
    
    // 绑定事件
    const saveBtn = div.querySelector('#pm-save-btn');
    const cancelBtn = div.querySelector('#pm-cancel-btn');
    const closeBtn = div.querySelector('#pm-close-btn');
    
    // 关闭弹窗的通用方法
    const closePrompt = () => {
      if (div.parentNode) div.remove();
      savePromptShown = false; // 重置状态
    };
    
    // 保存按钮事件
    saveBtn.addEventListener('click', async () => {
      // 显示加载状态
      const originalText = saveBtn.textContent;
      const originalBackground = saveBtn.style.background;
      saveBtn.textContent = '保存中...';
      saveBtn.disabled = true;
      saveBtn.style.opacity = '0.7';
      saveBtn.style.cursor = 'not-allowed';
      
      try {
        const result = await savePassword(username, password);
        closePrompt();
        if (result && result.success) {
          showNotification('密码保存成功！', 'success');
        } else {
          showNotification('密码保存失败：' + (result ? result.message : '未知错误'), 'error');
        }
      } catch (error) {
        console.error('保存密码时发生错误:', error);
        showNotification('密码保存失败，请重试', 'error');
        closePrompt();
      } finally {
        // 恢复按钮状态
        saveBtn.textContent = originalText;
        saveBtn.disabled = false;
        saveBtn.style.opacity = '1';
        saveBtn.style.cursor = 'pointer';
        saveBtn.style.background = originalBackground;
      }
    });
    
    cancelBtn.addEventListener('click', closePrompt);
    closeBtn.addEventListener('click', closePrompt);
    
    // 改进的悬停效果 - 保存按钮
    saveBtn.addEventListener('mouseenter', () => {
      if (!saveBtn.disabled) {
        saveBtn.style.transform = 'translateY(-1px)';
        saveBtn.style.boxShadow = '0 4px 12px rgba(66,133,244,0.4)';
      }
    });
    saveBtn.addEventListener('mouseleave', () => {
      if (!saveBtn.disabled) {
        saveBtn.style.transform = 'translateY(0)';
        saveBtn.style.boxShadow = '0 2px 8px rgba(66,133,244,0.3)';
      }
    });
    
    // 取消按钮悬停效果
    cancelBtn.addEventListener('mouseenter', () => {
      cancelBtn.style.background = '#f1f3f4';
      cancelBtn.style.borderColor = '#c8c9ca';
      cancelBtn.style.transform = 'translateY(-1px)';
    });
    cancelBtn.addEventListener('mouseleave', () => {
      cancelBtn.style.background = '#ffffff';
      cancelBtn.style.borderColor = '#dadce0';
      cancelBtn.style.transform = 'translateY(0)';
    });
    
    // 关闭按钮悬停效果
    closeBtn.addEventListener('mouseenter', () => {
      closeBtn.style.backgroundColor = '#f1f3f4';
      closeBtn.style.transform = 'scale(1.1)';
    });
    closeBtn.addEventListener('mouseleave', () => {
      closeBtn.style.backgroundColor = 'transparent';
      closeBtn.style.transform = 'scale(1)';
    });
    
    // 添加键盘ESC支持
    const handleKeyDown = (e) => {
      if (e.key === 'Escape') {
        closePrompt();
        document.removeEventListener('keydown', handleKeyDown);
      }
    };
    document.addEventListener('keydown', handleKeyDown);
    
    // 当弹窗被移除时，清理事件监听器
    const originalRemove = div.remove.bind(div);
    div.remove = () => {
      document.removeEventListener('keydown', handleKeyDown);
      originalRemove();
    };
    
    // 最后验证两个元素都有效
    if (!overlay || !div || !(overlay instanceof HTMLElement) || !(div instanceof HTMLElement)) {
      console.error('创建的元素无效:', { overlay, div });
      return null;
    }
    
    console.log('保存密码提示框创建成功');
    return { promptDiv: div, overlay };
    } catch (error) {
      console.error('创建保存密码提示框失败:', error);
      // 返回null以防止进一步错误
      return null;
    }
  }
  
  // 保存密码
  async function savePassword(username, password) {
    try {
      // 验证输入参数
      if (!username || !password || !currentDomain) {
        throw new Error('缺少必要的密码信息');
      }
      
      // 确保所有字段都是有效的字符串，避免null值
      const cleanUsername = String(username || '').trim();
      const cleanPassword = String(password || '');
      const cleanDomain = String(currentDomain || '').trim();
      
      // 更严格的密码验证
      if (!cleanUsername || cleanUsername.length < 1) {
        throw new Error('用户名不能为空');
      }
      if (!cleanPassword || cleanPassword.length < 1 || cleanPassword === 'null' || cleanPassword === 'undefined') {
        throw new Error('密码不能为空或无效');
      }
      if (!cleanDomain || cleanDomain.length < 1) {
        throw new Error('域名不能为空');
      }
      
      console.log('密码字段详细检查:', {
        originalPassword: typeof password,
        passwordLength: password ? password.length : 0,
        cleanPassword: typeof cleanPassword,
        cleanPasswordLength: cleanPassword.length,
        passwordPreview: cleanPassword ? cleanPassword.substring(0, 2) + '***' : '(空)',
        isValidPassword: cleanPassword && cleanPassword.length > 0 && cleanPassword !== 'null' && cleanPassword !== 'undefined'
      });
      
      // 构建完整的网站URL
      let websiteUrl = cleanDomain;
      if (!websiteUrl.startsWith('http://') && !websiteUrl.startsWith('https://')) {
        websiteUrl = `https://${websiteUrl}`;
      }
      
      // 获取当前时间的ISO字符串格式，用于DateTime字段
      const now = new Date().toISOString();
      
      // 确保website字段不为null或空
      const websiteForSave = websiteUrl && websiteUrl.trim() !== '' ? String(websiteUrl) : String(`https://${cleanDomain}`);
      
      console.log('准备保存的website字段:', {
        originalWebsiteUrl: websiteUrl,
        cleanDomain: cleanDomain,
        finalWebsite: websiteForSave
      });
      
      // 先尝试最简化版本，只包含绝对必需的字段
      const passwordData = {
        title: String(`${cleanDomain} - ${cleanUsername}`),
        username: String(cleanUsername),
        password: String(cleanPassword),
        website: websiteForSave,
        // 明确处理可能的问题字段
        id: null,
        createdAt: now,
        updatedAt: now
      };
      
      // 如果简化版本失败，准备完整版本
      const fullPasswordData = {
        // 必需字段 (required String)
        title: String(`${cleanDomain} - ${cleanUsername}`),
        username: String(cleanUsername),
        password: String(cleanPassword),
        
        // 可选字段，确保不为null
        website: websiteForSave,
        notes: '',
        category: '',
        iconUrl: '',
        
        // DateTime字段
        createdAt: now,
        updatedAt: now,
        
        // 其他字段
        id: null,
        customFields: {},
        isFavorite: false
      };
      
      // 验证必需字段都不为空
      if (!passwordData.title || passwordData.title.trim() === '') {
        throw new Error(`标题字段无效: "${passwordData.title}"`);
      }
      if (!passwordData.username || passwordData.username.trim() === '') {
        throw new Error(`用户名字段无效: "${passwordData.username}"`);
      }
      if (!passwordData.password || passwordData.password === 'null' || passwordData.password === 'undefined' || passwordData.password === '') {
        throw new Error(`密码字段无效: "${passwordData.password}"`);
      }
      
      // 先尝试简化版本
      console.log('尝试保存密码 - 简化版本:', {
        title: passwordData.title,
        username: passwordData.username,
        password: passwordData.password ? `***${passwordData.password.slice(-2)}` : '(空)',
        fieldCount: Object.keys(passwordData).length
      });
      
      let response = await safeSendMessage({
        action: 'savePassword',
        data: { password: passwordData }
      });
      
      // 如果简化版本失败，尝试多种格式
      if (!response || !response.success) {
        console.log('简化版本失败，尝试其他格式:', response?.error);
        
        // 格式1: 完整版本
        console.log('尝试完整版本...');
        response = await safeSendMessage({
          action: 'savePassword',
          data: { password: fullPasswordData }
        });
        
                 // 格式2: 如果还是失败，尝试不包含customFields
         if (!response || !response.success) {
           console.log('完整版本失败，尝试无customFields版本:', response?.error);
           const simpleData = {
             title: String(`${cleanDomain} - ${cleanUsername}`),
             username: String(cleanUsername),
             password: String(cleanPassword),
             website: websiteForSave,
             notes: '',
             id: null,
             createdAt: now,
             updatedAt: now,
             isFavorite: false
           };
          
          response = await safeSendMessage({
            action: 'savePassword',
            data: { password: simpleData }
          });
        }
        
                 // 格式3: 最后尝试，尝试不发送DateTime字段，让后端自动生成
         if (!response || !response.success) {
           console.log('无customFields版本失败，尝试让后端自动生成DateTime:', response?.error);
           const backendAutoData = {
             title: String(`${cleanDomain} - ${cleanUsername}`),
             username: String(cleanUsername),
             password: String(cleanPassword),
             website: websiteForSave,
             notes: '',
             isFavorite: false
           };
          
                                response = await safeSendMessage({
             action: 'savePassword',
             data: { password: backendAutoData }
           });
           
           // 格式4: 终极简化版本，只发送3个核心字段
           if (!response || !response.success) {
             console.log('后端自动生成DateTime失败，尝试终极简化版本:', response?.error);
             const ultimateSimpleData = {
               title: String(`${cleanDomain} - ${cleanUsername}`),
               username: String(cleanUsername),
               password: String(cleanPassword)
             };
             
             console.log('终极简化版本数据:', ultimateSimpleData);
             
             response = await safeSendMessage({
               action: 'savePassword',
               data: { password: ultimateSimpleData }
             });
           }
         }
      }
      
      console.log('保存密码响应:', response);
      
      if (response && response.success) {
        // 不在这里显示通知，让调用方处理
        
        // 更新可用密码列表
        if (response.data && response.data.password) {
          availablePasswords.push(response.data.password);
          console.log('密码保存成功，已添加到本地列表:', {
            savedPassword: {
              id: response.data.password.id,
              title: response.data.password.title,
              website: response.data.password.website,
              username: response.data.password.username
            },
            totalPasswords: availablePasswords.length
          });
        }
        
        // 重新获取该域名的所有密码，确保数据同步
        try {
          const currentDomain = window.location.hostname;
          const domainResponse = await safeSendMessage({
            action: 'getPasswordsByDomain',
            data: { domain: currentDomain }
          });
          
          if (domainResponse && domainResponse.success) {
            console.log('保存后重新获取域名密码:', domainResponse);
            handleDomainPasswords(domainResponse.data);
          }
        } catch (error) {
          console.error('保存后重新获取密码失败:', error);
        }
        
        // 返回成功结果
        return { success: true, message: '密码保存成功' };
      } else {
        const errorMsg = response?.error || '保存失败';
        console.error('密码保存失败:', errorMsg);
        // 不在这里显示通知，让调用方处理
        return { success: false, message: errorMsg };
      }
    } catch (error) {
      console.error('保存密码异常:', error);
      
      // 根据错误类型提供更友好的提示
      let errorMessage = '密码保存失败';
      
      if (error.message.includes('扩展连接已断开')) {
        errorMessage = '扩展连接已断开，请刷新页面后重试';
      } else if (error.message.includes('Extension context invalidated')) {
        errorMessage = '扩展需要重新加载，请刷新页面';
      } else if (error.message.includes('Could not establish connection')) {
        errorMessage = '无法连接到密码管理器，请检查应用是否运行';
      } else if (error.message) {
        errorMessage = `密码保存失败: ${error.message}`;
      }
      
      // 不在这里显示通知，让调用方处理
      return { success: false, message: errorMessage };
    }
  }
  
  // 添加自动填充按钮
  function addAutoFillButton() {
    if (!passwordField || availablePasswords.length === 0) return;
    
    // 避免重复添加
    if (document.getElementById('password-manager-autofill-btn')) return;
    
    const button = document.createElement('button');
    button.id = 'password-manager-autofill-btn';
    button.type = 'button';
    button.innerHTML = '🔐';
    button.title = '自动填充密码';
    button.style.cssText = `
      position: absolute;
      right: 8px;
      top: 50%;
      transform: translateY(-50%);
      background: #1a73e8;
      color: white;
      border: none;
      border-radius: 4px;
      width: 24px;
      height: 24px;
      cursor: pointer;
      font-size: 12px;
      z-index: 1000;
      display: flex;
      align-items: center;
      justify-content: center;
    `;
    
    // 设置密码字段为相对定位
    const computedStyle = window.getComputedStyle(passwordField);
    if (computedStyle.position === 'static') {
      passwordField.style.position = 'relative';
    }
    
    // 确保有足够的右边距
    passwordField.style.paddingRight = '32px';
    
    button.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      showPasswordSelector();
    });
    
    // 将按钮添加到密码字段的父容器
    const container = passwordField.parentElement;
    if (container) {
      container.style.position = 'relative';
      container.appendChild(button);
    }
  }
  
  // 显示密码选择器
  function showPasswordSelector() {
    if (availablePasswords.length === 0) {
      showNotification('没有找到该网站的保存密码', 'info');
      return;
    }
    
    if (availablePasswords.length === 1) {
      fillPasswordFromSelection(availablePasswords[0]);
      return;
    }
    
    // 创建选择器
    const selector = createPasswordSelector();
    document.body.appendChild(selector);
  }
  
  // 创建密码选择器
  function createPasswordSelector() {
    const div = document.createElement('div');
    div.id = 'password-manager-selector';
    div.style.cssText = `
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      background: white;
      border: 1px solid #e0e0e0;
      border-radius: 8px;
      padding: 20px;
      box-shadow: 0 8px 24px rgba(0,0,0,0.15);
      z-index: 10001;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      max-width: 400px;
      min-width: 300px;
    `;
    
    let html = `
      <div style="margin-bottom: 16px;">
        <h3 style="margin: 0; color: #333; font-size: 16px;">选择要填充的密码</h3>
      </div>
      <div style="max-height: 300px; overflow-y: auto;">
    `;
    
    availablePasswords.forEach((password, index) => {
      html += `
        <div class="password-option" data-index="${index}" style="
          padding: 12px;
          border: 1px solid #e0e0e0;
          border-radius: 4px;
          margin-bottom: 8px;
          cursor: pointer;
          transition: background-color 0.2s;
        ">
          <div style="font-weight: 600; color: #333;">${password.title || password.website}</div>
          <div style="font-size: 13px; color: #666;">${password.username || password.email}</div>
        </div>
      `;
    });
    
    html += `
      </div>
      <div style="margin-top: 16px; text-align: right;">
        <button id="pm-selector-cancel" style="
          background: #f1f3f4;
          color: #333;
          border: none;
          padding: 8px 16px;
          border-radius: 4px;
          cursor: pointer;
        ">取消</button>
      </div>
    `;
    
    div.innerHTML = html;
    
    // 绑定事件
    div.querySelectorAll('.password-option').forEach(option => {
      option.addEventListener('click', () => {
        const index = parseInt(option.dataset.index);
        fillPasswordFromSelection(availablePasswords[index]);
        div.remove();
      });
      
      option.addEventListener('mouseenter', () => {
        option.style.backgroundColor = '#f8f9fa';
      });
      
      option.addEventListener('mouseleave', () => {
        option.style.backgroundColor = 'white';
      });
    });
    
    div.querySelector('#pm-selector-cancel').addEventListener('click', () => {
      div.remove();
    });
    
    // 点击背景关闭
    div.addEventListener('click', (e) => {
      if (e.target === div) {
        div.remove();
      }
    });
    
    return div;
  }
  
  // 尝试填充密码（包含检测逻辑）
  async function attemptPasswordFill(passwordData) {
    console.log('🚀 ===== 开始密码填充流程 =====');
    console.log('📦 填充数据:', {
      title: passwordData.title || '(无标题)',
      website: passwordData.website || '(无网站)',
      username: passwordData.username ? `[长度: ${passwordData.username.length}]` : '(无用户名)',
      password: passwordData.password ? `[长度: ${passwordData.password.length}]` : '(无密码)',
      email: passwordData.email || '(无邮箱)'
    });
    
    // 重新检测当前页面的表单和输入框
    console.log('🔍 第一阶段：检测页面输入框');
    const currentFormAnalysis = detectCurrentFormInputs();
    
    if (!currentFormAnalysis.hasValidInputs) {
      console.log('❌ 第一阶段失败：未检测到有效的登录输入框');
      console.log('🔍 检测失败详情:', currentFormAnalysis);
      
      // 提供用户友好的错误信息
      console.log('🚫 ===== 填充流程结束 (检测阶段失败) =====');
      
      // 根据具体情况提供不同的友好提示
      let userFriendlyError;
      if (currentFormAnalysis.details.totalInputs === 0) {
        userFriendlyError = '页面没有输入框，可能还在加载中';
      } else if (currentFormAnalysis.details.passwordInputs === 0) {
        userFriendlyError = '这个页面不是登录页面，没有密码输入框';
      } else {
        userFriendlyError = '登录框可能被隐藏了，请尝试点击登录按钮';
      }
      
      return {
        success: false,
        error: userFriendlyError,
        details: currentFormAnalysis.details,
        debugInfo: {
          总输入框: currentFormAnalysis.details.totalInputs,
          密码框: currentFormAnalysis.details.passwordInputs,
          文本框: currentFormAnalysis.details.textInputs,
          邮箱框: currentFormAnalysis.details.emailInputs,
          隐藏框: currentFormAnalysis.details.hiddenInputs || 0,
          建议: currentFormAnalysis.details.totalInputs === 0 
            ? '页面中没有找到任何输入框，请确保页面已完全加载' 
            : currentFormAnalysis.details.passwordInputs === 0 
              ? '页面中没有密码输入框，请确保您在登录页面' 
              : '页面中的密码输入框都不可见或不可用，请检查页面状态'
        }
      };
      }
      
      console.log('✅ 第一阶段成功：检测到可用输入框');
      console.log('🎯 第二阶段：开始执行填充');
      
      // 尝试填充
      let fillSuccess = false;
      let filledFields = [];
      let fillResults = [];
      
      try {
        // 填充用户名
        if (currentFormAnalysis.usernameField && passwordData.username) {
          console.log('👤 开始填充用户名字段');
          const usernameResult = fillInputField(currentFormAnalysis.usernameField, passwordData.username, '用户名');
          fillResults.push(usernameResult);
          if (usernameResult.success) {
            filledFields.push('用户名');
            console.log('✅ 用户名填充成功');
          } else {
            console.log('❌ 用户名填充失败:', usernameResult.error);
          }
        } else {
          if (!currentFormAnalysis.usernameField) {
            console.log('ℹ️ 跳过用户名填充：未检测到用户名字段');
          } else if (!passwordData.username) {
            console.log('ℹ️ 跳过用户名填充：无用户名数据');
          }
        }
        
        // 填充密码（密码字段是必须的）
        if (currentFormAnalysis.passwordField && passwordData.password) {
          console.log('🔐 开始填充密码字段');
          const passwordResult = fillInputField(currentFormAnalysis.passwordField, passwordData.password, '密码');
          fillResults.push(passwordResult);
          if (passwordResult.success) {
            filledFields.push('密码');
            fillSuccess = true;
            console.log('✅ 密码填充成功');
          } else {
            console.log('❌ 密码填充失败:', passwordResult.error);
          }
        } else {
          console.log('❌ 密码填充条件不满足:', {
            hasPasswordField: !!currentFormAnalysis.passwordField,
            hasPasswordData: !!passwordData.password
          });
          return {
            success: false,
            error: '未找到密码字段或密码数据为空'
          };
        }
      
              console.log('🔬 第三阶段：验证填充结果');
        
        // 验证填充结果
        if (fillSuccess) {
          // 立即验证
          let passwordFieldValue = currentFormAnalysis.passwordField.value;
          let usernameFieldValue = currentFormAnalysis.usernameField ? currentFormAnalysis.usernameField.value : '';
          
          console.log('📊 立即验证结果:', {
            填充字段数: filledFields.length,
            已填充字段: filledFields.join('、'),
            密码字段值: passwordFieldValue || '(空)',
            用户名字段值: usernameFieldValue || '(空)',
            预期密码: passwordData.password || '(空)',
            预期用户名: passwordData.username || '(空)',
            密码匹配: passwordFieldValue === passwordData.password ? '✅' : '❌',
            用户名匹配: !passwordData.username || usernameFieldValue === passwordData.username ? '✅' : '❌'
          });
          
          // 如果立即验证成功，直接返回成功
          if (passwordFieldValue === passwordData.password) {
            console.log('🎉 立即验证成功：密码匹配');
            console.log('✅ ===== 填充流程完成 (成功) =====');
            return {
              success: true,
              message: `填充成功！已填入：${filledFields.join('、')}`,
              details: fillResults,
              analysis: currentFormAnalysis.analysis
            };
          }
          
          // 如果立即验证失败，等待一段时间后再次验证（给页面时间处理）
          console.log('⏱️ 立即验证失败，等待延迟验证...');
          await new Promise(resolve => setTimeout(resolve, 50)); // 等待50ms
          
          // 延迟验证
          passwordFieldValue = currentFormAnalysis.passwordField.value;
          usernameFieldValue = currentFormAnalysis.usernameField ? currentFormAnalysis.usernameField.value : '';
          
          console.log('📊 延迟验证结果:', {
            密码字段值: passwordFieldValue || '(空)',
            用户名字段值: usernameFieldValue || '(空)',
            预期密码: passwordData.password || '(空)',
            预期用户名: passwordData.username || '(空)',
            密码匹配: passwordFieldValue === passwordData.password ? '✅' : '❌',
            用户名匹配: !passwordData.username || usernameFieldValue === passwordData.username ? '✅' : '❌'
          });
          
          if (passwordFieldValue === passwordData.password) {
            console.log('🎉 延迟验证成功：密码匹配');
            console.log('✅ ===== 填充流程完成 (成功) =====');
            return {
              success: true,
              message: `填充成功！已填入：${filledFields.join('、')}`,
              details: fillResults,
              analysis: currentFormAnalysis.analysis
            };
          } else {
            // 检查字段值是否至少有内容（可能是页面修改了值的格式）
            const hasContent = passwordFieldValue && passwordFieldValue.length > 0;
            if (hasContent) {
              console.log('⚠️ 密码字段有内容但不完全匹配，可能是页面处理导致');
              console.log('✅ ===== 填充流程完成 (成功但值可能被修改) =====');
              return {
                success: true,
                message: `填充完成！已填入：${filledFields.join('、')}（值可能被页面处理）`,
                details: fillResults,
                analysis: currentFormAnalysis.analysis
              };
            } else {
              console.log('❌ 延迟验证失败：密码字段仍为空');
              console.warn('⚠️ 密码值验证失败，可能原因:', {
                框架拦截: '页面可能使用React/Vue等框架的受控组件',
                特殊处理: '页面可能有自定义的输入处理逻辑',
                延迟更新: '页面可能需要更长时间来处理值的变化',
                安全限制: '页面可能有安全限制阻止脚本设置值'
              });
              console.log('🚫 ===== 填充流程结束 (验证失败) =====');
              return {
                success: false,
                error: '密码可能已填入但检测不到，请手动确认',
                details: fillResults,
                analysis: currentFormAnalysis.analysis
              };
            }
          }
        } else {
          console.log('❌ 第二阶段失败：密码字段填充失败');
          console.log('🚫 ===== 填充流程结束 (填充失败) =====');
          return {
            success: false,
            error: '无法向密码框输入内容，请手动填写',
            details: fillResults,
            analysis: currentFormAnalysis.analysis
          };
        }
      } catch (error) {
        console.error('💥 填充过程中发生异常:', {
          message: error.message,
          stack: error.stack,
          formAnalysis: currentFormAnalysis
        });
        console.log('🚫 ===== 填充流程结束 (异常) =====');
        return {
          success: false,
          error: '填充时遇到技术问题，建议手动输入',
          details: fillResults,
          analysis: currentFormAnalysis.analysis
        };
      }
  }
  
  // 检测当前页面的表单输入框
  function detectCurrentFormInputs() {
    console.log('🔍 开始智能检测页面输入框...');
    console.log('📊 页面基本信息:', {
      url: window.location.href,
      title: document.title,
      domain: window.location.hostname
    });
    
    // 使用多种方式查找input元素，确保不遗漏
    const methods = [
      { name: 'document.querySelectorAll("input")', selector: 'input' },
      { name: 'document.getElementsByTagName("input")', selector: null },
      { name: 'document.querySelectorAll("input[type]")', selector: 'input[type]' },
      { name: 'document.querySelectorAll("*[type*=text], *[type*=password], *[type*=email]")', selector: '*[type*="text"], *[type*="password"], *[type*="email"]' }
    ];
    
    const allInputSets = [];
    
    // 尝试不同的查找方法
    methods.forEach(method => {
      let inputs;
      if (method.selector) {
        inputs = document.querySelectorAll(method.selector);
      } else {
        inputs = document.getElementsByTagName('input');
      }
      console.log(`🔎 ${method.name}: 找到 ${inputs.length} 个元素`);
      allInputSets.push(Array.from(inputs));
    });
    
    // 检查iframe中的input（仅限同域iframe）
    const iframes = document.querySelectorAll('iframe');
    console.log(`🖼️ 检查 ${iframes.length} 个iframe...`);
    iframes.forEach((iframe, index) => {
      try {
        if (iframe.contentDocument) {
          const iframeInputs = iframe.contentDocument.querySelectorAll('input');
          console.log(`  🔎 iframe[${index}]: 找到 ${iframeInputs.length} 个输入框`);
          if (iframeInputs.length > 0) {
            allInputSets.push(Array.from(iframeInputs));
          }
        }
      } catch (error) {
        // 跨域iframe访问被阻止，这是正常的
        console.log(`  ⚠️ iframe[${index}]: 跨域访问被阻止`);
      }
    });
    
    // 深度搜索：检查所有可能包含form的元素
    const allElements = document.querySelectorAll('*');
    let deepSearchCount = 0;
    allElements.forEach(element => {
      if (element.tagName && element.tagName.toLowerCase() === 'input') {
        deepSearchCount++;
      }
    });
    console.log(`🕳️ 深度搜索验证: 发现 ${deepSearchCount} 个input元素`);
    
    // 合并并去重所有找到的input元素
    const allInputsSet = new Set();
    allInputSets.forEach(inputSet => {
      inputSet.forEach(input => {
        if (input && input.nodeType === Node.ELEMENT_NODE) {
          allInputsSet.add(input);
        }
      });
    });
    
    const allInputs = Array.from(allInputsSet);
    
    console.log(`📊 合并后总计发现 ${allInputs.length} 个独特的input元素`);
    
    let details = {
      totalInputs: allInputs.length,
      passwordInputs: 0,
      textInputs: 0,
      emailInputs: 0,
      searchInputs: 0,
      hiddenInputs: 0,
      visibleInputs: 0,
      invisibleInputs: 0
    };
    
    // 记录所有输入框的详细信息
    console.log(`📋 页面输入框详细分析:`);
    allInputs.forEach((input, index) => {
      const isVisible = isVisibleAndEnabled(input);
      const fieldDesc = getFieldDescription(input);
      const rect = input.getBoundingClientRect();
      const computedStyle = window.getComputedStyle(input);
      
      // 更详细的可见性分析
      const visibilityInfo = {
        display: computedStyle.display,
        visibility: computedStyle.visibility,
        opacity: computedStyle.opacity,
        width: rect.width,
        height: rect.height,
        inViewport: rect.top >= 0 && rect.left >= 0 && rect.bottom <= window.innerHeight && rect.right <= window.innerWidth,
        hasSize: rect.width > 0 && rect.height > 0
      };
      
      if (isVisible) {
        details.visibleInputs++;
      } else {
        details.invisibleInputs++;
      }
      
      console.log(`  ${index + 1}. ${input.tagName}[type="${input.type}"]`, {
        name: fieldDesc.name || '(无)',
        id: fieldDesc.id || '(无)', 
        placeholder: fieldDesc.placeholder || '(无)',
        className: input.className || '(无)',
        visible: isVisible ? '✅ 可见' : '❌ 隐藏',
        disabled: input.disabled ? '❌ 禁用' : '✅ 启用',
        readOnly: input.readOnly ? '❌ 只读' : '✅ 可写',
        form: input.form ? `表单#${input.form.id || input.form.name || '(无标识)'}` : '无表单',
        position: `(${Math.round(rect.left)}, ${Math.round(rect.top)})`,
        size: `${Math.round(rect.width)}×${Math.round(rect.height)}`,
        styles: visibilityInfo,
        parentElement: input.parentElement ? input.parentElement.tagName : '无父元素'
      });
    });
    
    // 分析所有输入框
    const inputAnalysis = analyzeAllInputs(allInputs, details);
    
    // 记录候选字段的评分详情
    console.log('🎯 密码字段候选评分:');
    inputAnalysis.passwordCandidates.forEach((candidate, index) => {
      const desc = getFieldDescription(candidate.input);
      console.log(`  ${index + 1}. 评分: ${candidate.score}分`, {
        element: `${candidate.input.tagName}[type="${candidate.input.type}"]`,
        name: desc.name || '(无)',
        id: desc.id || '(无)',
        placeholder: desc.placeholder || '(无)'
      });
    });
    
    console.log('👤 用户名字段候选评分:');
    inputAnalysis.usernameCandidates.forEach((candidate, index) => {
      const desc = getFieldDescription(candidate.input);
      console.log(`  ${index + 1}. 评分: ${candidate.score}分`, {
        element: `${candidate.input.tagName}[type="${candidate.input.type}"]`,
        name: desc.name || '(无)',
        id: desc.id || '(无)',
        placeholder: desc.placeholder || '(无)'
      });
    });
    
    // 查找最佳的密码字段
    const passwordField = findBestPasswordField(inputAnalysis.passwordCandidates);
    
    // 基于密码字段查找最佳的用户名字段
    const usernameField = findBestUsernameField(inputAnalysis.usernameCandidates, passwordField);
    
    const hasValidInputs = passwordField !== null;
    
    // 详细记录最终选择结果
    console.log('🏆 最终检测结果:');
    console.log('  密码字段:', passwordField ? {
      element: getFieldDescription(passwordField),
      position: getElementPosition(passwordField),
      styles: {
        display: window.getComputedStyle(passwordField).display,
        visibility: window.getComputedStyle(passwordField).visibility,
        opacity: window.getComputedStyle(passwordField).opacity
      }
    } : '❌ 未找到');
    
    console.log('  用户名字段:', usernameField ? {
      element: getFieldDescription(usernameField),
      position: getElementPosition(usernameField),
      styles: {
        display: window.getComputedStyle(usernameField).display,
        visibility: window.getComputedStyle(usernameField).visibility,
        opacity: window.getComputedStyle(usernameField).opacity
      }
    } : '❌ 未找到');
    
    console.log('📈 统计信息:', {
      hasValidInputs,
      passwordCandidatesCount: inputAnalysis.passwordCandidates.length,
      usernameCandidatesCount: inputAnalysis.usernameCandidates.length,
      details
    });
    
    console.log('🔍 检测总结:', {
      '🎯 检测方法': '多重查找策略',
      '📊 发现总数': allInputs.length,
      '✅ 可见输入框': details.visibleInputs,
      '❌ 不可见输入框': details.invisibleInputs,
      '🔐 密码候选': inputAnalysis.passwordCandidates.length,
      '👤 用户名候选': inputAnalysis.usernameCandidates.length,
      '🏆 最终结果': hasValidInputs ? '找到可填充字段' : '未找到可填充字段'
    });
    
    return {
      hasValidInputs,
      usernameField,
      passwordField,
      details,
      analysis: inputAnalysis // 返回分析详情供后续使用
    };
  }

  // 分析所有输入框
  function analyzeAllInputs(allInputs, details) {
    const passwordCandidates = [];
    const usernameCandidates = [];
    
    for (const input of allInputs) {
      // 基础可见性检查
      if (!isVisibleAndEnabled(input)) {
        if (input.type === 'hidden') {
          details.hiddenInputs++;
        }
        continue;
      }
      
      // 统计输入框类型
      switch (input.type.toLowerCase()) {
        case 'password':
          details.passwordInputs++;
          break;
        case 'text':
          details.textInputs++;
          break;
        case 'email':
          details.emailInputs++;
          break;
        case 'search':
          details.searchInputs++;
          break;
      }
      
      // 分析密码字段候选
      if (input.type === 'password') {
        const score = calculatePasswordFieldScore(input);
        passwordCandidates.push({ input, score, type: 'password' });
      }
      
      // 分析用户名字段候选
      if (['text', 'email', 'tel'].includes(input.type.toLowerCase())) {
        const score = calculateUsernameFieldScore(input);
        if (score > 0) {
          usernameCandidates.push({ input, score, type: input.type });
        }
      }
    }
    
    // 按分数排序
    passwordCandidates.sort((a, b) => b.score - a.score);
    usernameCandidates.sort((a, b) => b.score - a.score);
    
    return { passwordCandidates, usernameCandidates };
  }

  // 计算密码字段评分
  function calculatePasswordFieldScore(input) {
    let score = 100; // 基础分
    
    // 检查字段属性
    const attributes = getFieldAttributes(input);
    
    // 根据名称和ID评分
    if (attributes.name) {
      if (/^(password|passwd|pwd)$/i.test(attributes.name)) {
        score += 50;
      } else if (/password|passwd|pwd/i.test(attributes.name)) {
        score += 30;
      } else if (/confirm|repeat|again|check/i.test(attributes.name)) {
        score -= 30; // 可能是确认密码
      }
    }
    
    if (attributes.id) {
      if (/^(password|passwd|pwd)$/i.test(attributes.id)) {
        score += 40;
      } else if (/password|passwd|pwd/i.test(attributes.id)) {
        score += 25;
      } else if (/confirm|repeat|again|check/i.test(attributes.id)) {
        score -= 25;
      }
    }
    
    // 根据autocomplete属性评分
    if (attributes.autocomplete) {
      if (attributes.autocomplete.includes('current-password')) {
        score += 40;
      } else if (attributes.autocomplete.includes('new-password')) {
        score -= 20; // 可能是注册页面
      }
    }
    
    // 检查placeholder
    if (attributes.placeholder) {
      if (/密码|password|passwd|pwd/i.test(attributes.placeholder)) {
        score += 20;
      } else if (/确认|confirm|repeat|again/i.test(attributes.placeholder)) {
        score -= 20;
      }
    }
    
    // 检查label
    if (attributes.label) {
      if (/^(密码|password)$/i.test(attributes.label)) {
        score += 30;
      } else if (/密码|password/i.test(attributes.label)) {
        score += 15;
      } else if (/确认|重复|再次|confirm|repeat|again/i.test(attributes.label)) {
        score -= 20;
      }
    }
    
    // 位置评分（第一个密码字段通常是主密码）
    const allPasswordInputs = document.querySelectorAll('input[type="password"]');
    const index = Array.from(allPasswordInputs).indexOf(input);
    if (index === 0) {
      score += 20;
    } else if (index === 1) {
      score -= 10; // 可能是确认密码
    }
    
    // 表单上下文评分
    const form = input.closest('form');
    if (form) {
      const formText = form.textContent.toLowerCase();
      if (/login|sign.*in|登录|登入/i.test(formText)) {
        score += 25;
      } else if (/register|sign.*up|注册|创建/i.test(formText)) {
        score -= 15;
      }
    }
    
    return Math.max(0, score);
  }

  // 计算用户名字段评分
  function calculateUsernameFieldScore(input) {
    let score = 0;
    
    const attributes = getFieldAttributes(input);
    
    // 根据类型评分
    if (input.type === 'email') {
      score += 60;
    } else if (input.type === 'tel') {
      score += 40;
    } else if (input.type === 'text') {
      score += 30;
    }
    
    // 根据名称评分
    if (attributes.name) {
      const name = attributes.name.toLowerCase();
      if (/^(username|user|email|login|account)$/i.test(name)) {
        score += 50;
      } else if (/username|user|email|login|account|mail/i.test(name)) {
        score += 30;
      } else if (/^(用户名|邮箱|账号|手机|电话)$/i.test(name)) {
        score += 45;
      } else if (/用户名|邮箱|账号|手机|电话|登录名/i.test(name)) {
        score += 25;
      } else if (/search|query|keyword|搜索|查询/i.test(name)) {
        score -= 40; // 搜索框
      }
    }
    
    // 根据ID评分
    if (attributes.id) {
      const id = attributes.id.toLowerCase();
      if (/^(username|user|email|login|account)$/i.test(id)) {
        score += 40;
      } else if (/username|user|email|login|account|mail/i.test(id)) {
        score += 25;
      } else if (/^(用户名|邮箱|账号|手机)$/i.test(id)) {
        score += 35;
      } else if (/search|query|keyword|搜索|查询/i.test(id)) {
        score -= 35;
      }
    }
    
    // 根据autocomplete属性评分
    if (attributes.autocomplete) {
      if (attributes.autocomplete.includes('username')) {
        score += 40;
      } else if (attributes.autocomplete.includes('email')) {
        score += 35;
      } else if (attributes.autocomplete.includes('tel')) {
        score += 30;
      }
    }
    
    // 根据placeholder评分
    if (attributes.placeholder) {
      if (/^(用户名|邮箱|账号|手机|username|email|phone)$/i.test(attributes.placeholder)) {
        score += 30;
      } else if (/用户名|邮箱|账号|手机|电话|username|email|phone|login/i.test(attributes.placeholder)) {
        score += 20;
      } else if (/搜索|查找|search|find|query/i.test(attributes.placeholder)) {
        score -= 30;
      }
    }
    
    // 根据label评分
    if (attributes.label) {
      if (/^(用户名|邮箱|账号|手机|username|email)$/i.test(attributes.label)) {
        score += 25;
      } else if (/用户名|邮箱|账号|手机|username|email|phone|login/i.test(attributes.label)) {
        score += 15;
      }
    }
    
    // 输入框大小和样式评分
    const style = window.getComputedStyle(input);
    const width = parseInt(style.width);
    if (width > 0) {
      if (width < 100) {
        score -= 20; // 太小的输入框可能不是用户名
      } else if (width > 200) {
        score += 10; // 合理大小的输入框
      }
    }
    
    return Math.max(0, score);
  }

  // 获取字段属性
  function getFieldAttributes(input) {
    return {
      name: input.name || '',
      id: input.id || '',
      className: input.className || '',
      placeholder: input.placeholder || '',
      autocomplete: input.autocomplete || '',
      label: getFieldLabel(input),
      type: input.type || 'text'
    };
  }

  // 查找最佳密码字段
  function findBestPasswordField(passwordCandidates) {
    if (passwordCandidates.length === 0) return null;
    
    // 过滤掉明显的确认密码字段
    const filteredCandidates = passwordCandidates.filter(candidate => {
      const attributes = getFieldAttributes(candidate.input);
      const allText = `${attributes.name} ${attributes.id} ${attributes.placeholder} ${attributes.label}`.toLowerCase();
      
      // 如果明确包含确认密码的关键词，且不是唯一的密码字段，则排除
      const isConfirmPassword = /confirm|repeat|again|check|确认|重复|再次/.test(allText);
      return !isConfirmPassword || passwordCandidates.length === 1;
    });
    
    const candidates = filteredCandidates.length > 0 ? filteredCandidates : passwordCandidates;
    return candidates[0].input; // 返回评分最高的
  }

  // 查找最佳用户名字段
  function findBestUsernameField(usernameCandidates, passwordField) {
    if (usernameCandidates.length === 0) return null;
    if (!passwordField) return usernameCandidates[0]?.input || null;
    
    const passwordForm = passwordField.closest('form');
    
    // 优先选择与密码字段在同一表单中的字段
    const sameFormCandidates = usernameCandidates.filter(candidate => {
      const candidateForm = candidate.input.closest('form');
      return candidateForm === passwordForm;
    });
    
    if (sameFormCandidates.length > 0) {
      // 在同一表单中，选择位置在密码字段之前且距离最近的
      const passwordPosition = getElementPosition(passwordField);
      
      let bestCandidate = sameFormCandidates[0];
      let bestDistance = Infinity;
      
      for (const candidate of sameFormCandidates) {
        const candidatePosition = getElementPosition(candidate.input);
        
        // 计算距离（优先考虑在密码字段之前的）
        let distance;
        if (candidatePosition.top < passwordPosition.top || 
           (candidatePosition.top === passwordPosition.top && candidatePosition.left < passwordPosition.left)) {
          distance = Math.abs(passwordPosition.top - candidatePosition.top) + 
                    Math.abs(passwordPosition.left - candidatePosition.left);
        } else {
          distance = 1000 + Math.abs(passwordPosition.top - candidatePosition.top) + 
                    Math.abs(passwordPosition.left - candidatePosition.left);
        }
        
        // 结合评分和距离
        const combinedScore = candidate.score - distance * 0.1;
        
        if (combinedScore > bestCandidate.score - bestDistance * 0.1) {
          bestCandidate = candidate;
          bestDistance = distance;
        }
      }
      
      return bestCandidate.input;
    }
    
    // 如果没有同表单的字段，返回评分最高的
    return usernameCandidates[0].input;
  }

  // 获取元素位置
  function getElementPosition(element) {
    const rect = element.getBoundingClientRect();
    return {
      top: rect.top + window.scrollY,
      left: rect.left + window.scrollX
    };
  }

  // 获取字段描述信息
  function getFieldDescription(input) {
    const attributes = getFieldAttributes(input);
    return {
      tagName: input.tagName,
      type: input.type,
      name: attributes.name,
      id: attributes.id,
      placeholder: attributes.placeholder,
      hasLabel: !!attributes.label
    };
  }

  // 强大的输入框填充函数
  function fillInputField(inputElement, value, fieldName) {
    console.log(`🎯 开始填充${fieldName}:`);
    
    // 记录输入框详细信息
    const elementDesc = getFieldDescription(inputElement);
    const elementPosition = getElementPosition(inputElement);
    const elementStyles = window.getComputedStyle(inputElement);
    
    console.log('  📝 目标输入框信息:', {
      element: elementDesc,
      position: elementPosition,
      dimensions: {
        width: inputElement.offsetWidth + 'px',
        height: inputElement.offsetHeight + 'px'
      },
      styles: {
        display: elementStyles.display,
        visibility: elementStyles.visibility,
        opacity: elementStyles.opacity
      },
      状态: {
        可见: isVisibleAndEnabled(inputElement) ? '✅' : '❌',
        禁用: inputElement.disabled ? '❌' : '✅',
        只读: inputElement.readOnly ? '❌' : '✅'
      }
    });
    
    console.log('  🔒 填充数据:', {
      fieldName: fieldName,
      valueLength: value ? value.length : 0,
      valueType: typeof value,
      hasValue: !!value
    });
    
    if (!inputElement || !value) {
      const error = !inputElement ? '输入框元素不存在' : '填充值为空';
      console.log(`  ❌ 填充${fieldName}失败:`, error);
      return {
        success: false,
        fieldName: fieldName,
        error: error
      };
    }
    
    try {
      // 保存原始值以便对比
      const originalValue = inputElement.value;
      console.log('  📊 填充前状态:', {
        originalValue: originalValue || '(空)',
        originalLength: originalValue ? originalValue.length : 0
      });
      
      // 记录填充过程的每个步骤
      const fillSteps = [];
      
      // 步骤1: 聚焦到输入框
      console.log('  🎯 步骤1: 聚焦输入框');
      inputElement.focus();
      fillSteps.push('聚焦输入框');
      
      // 步骤2: 直接设置value属性
      console.log('  📝 步骤2: 直接设置value属性');
      inputElement.value = value;
      const valueAfterDirect = inputElement.value;
      console.log(`    设置后值: "${valueAfterDirect}" (长度: ${valueAfterDirect.length})`);
      fillSteps.push(`直接设置value: ${valueAfterDirect === value ? '✅ 成功' : '❌ 失败'}`);
      
      // 步骤3: 使用原生的value setter（处理React等框架的受控组件）
      console.log('  ⚛️ 步骤3: 使用原生value setter (React兼容)');
      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
      if (nativeInputValueSetter) {
        nativeInputValueSetter.call(inputElement, value);
        const valueAfterNative = inputElement.value;
        console.log(`    原生setter后值: "${valueAfterNative}" (长度: ${valueAfterNative.length})`);
        fillSteps.push(`原生setter: ${valueAfterNative === value ? '✅ 成功' : '❌ 失败'}`);
      } else {
        console.log('    ⚠️ 原生setter不可用');
        fillSteps.push('原生setter: ⚠️ 不可用');
      }
      
      // 步骤4: 模拟用户输入（某些情况下更可靠）
      console.log('  ⌨️ 步骤4: 模拟用户输入');
      try {
        inputElement.select();
        const insertResult = document.execCommand('insertText', false, value);
        const valueAfterInsert = inputElement.value;
        console.log(`    插入文本后值: "${valueAfterInsert}" (长度: ${valueAfterInsert.length})`);
        console.log(`    insertText命令结果: ${insertResult ? '✅ 成功' : '❌ 失败'}`);
        fillSteps.push(`模拟输入: ${insertResult && valueAfterInsert === value ? '✅ 成功' : '❌ 失败'}`);
      } catch (e) {
        console.log(`    ❌ 模拟输入失败: ${e.message}`);
        fillSteps.push('模拟输入: ❌ 异常');
      }
      
      // 步骤5: 触发各种事件以确保框架能够检测到变化
      console.log('  🎪 步骤5: 触发事件序列');
      const events = [
        'focus',
        'input', 
        'change',
        'keydown',
        'keyup',
        'blur'
      ];
      
      const eventResults = [];
      events.forEach(eventType => {
        let event;
        let eventSuccess = false;
        
        try {
          if (eventType === 'input') {
            event = new InputEvent(eventType, {
              bubbles: true,
              cancelable: true,
              inputType: 'insertText',
              data: value
            });
          } else if (eventType === 'keydown' || eventType === 'keyup') {
            event = new KeyboardEvent(eventType, {
              bubbles: true,
              cancelable: true,
              key: 'Enter',
              code: 'Enter'
            });
          } else {
            event = new Event(eventType, {
              bubbles: true,
              cancelable: true
            });
          }
          
          inputElement.dispatchEvent(event);
          eventSuccess = true;
        } catch (e) {
          console.warn(`    ❌ 触发${eventType}事件失败:`, e.message);
        }
        
        eventResults.push(`${eventType}: ${eventSuccess ? '✅' : '❌'}`);
      });
      
      console.log('    事件触发结果:', eventResults);
      fillSteps.push(`事件触发: ${eventResults.filter(r => r.includes('✅')).length}/${events.length} 成功`);
      
      // 步骤6: 延迟验证和二次设置
      console.log('  ⏱️ 步骤6: 延迟验证');
      setTimeout(() => {
        const delayedValue = inputElement.value;
        console.log(`    延迟检查值: "${delayedValue}" (目标: "${value}")`);
        
        // 最后再次确保值被设置
        if (delayedValue !== value) {
          console.log('    🔄 值不匹配，重新设置');
          inputElement.value = value;
          inputElement.dispatchEvent(new Event('change', { bubbles: true }));
          const finalDelayedValue = inputElement.value;
          console.log(`    重设后值: "${finalDelayedValue}"`);
        }
      }, 10);
      
      // 验证填充结果
      const finalValue = inputElement.value;
      const success = finalValue === value;
      
      console.log(`  🏁 ${fieldName}填充结果汇总:`);
      console.log('    📋 步骤记录:', fillSteps);
      console.log('    📊 值对比:', {
        原始值: originalValue || '(空)',
        目标值: value,
        最终值: finalValue,
        长度对比: `${originalValue?.length || 0} → ${finalValue.length} (目标: ${value.length})`,
        匹配状态: success ? '✅ 完全匹配' : '❌ 不匹配'
      });
      
      const result = {
        success: success,
        fieldName: fieldName,
        originalValue: originalValue,
        targetValue: value,
        finalValue: finalValue,
        fillSteps: fillSteps,
        message: success ? `${fieldName}填充成功` : `${fieldName}填充失败：值未正确设置`
      };
      
      console.log(`  🎯 ${fieldName}填充${success ? '成功' : '失败'}!`);
      return result;
      
    } catch (error) {
      console.error(`  💥 填充${fieldName}时发生异常:`, {
        message: error.message,
        stack: error.stack,
        inputElement: getFieldDescription(inputElement)
      });
      return {
        success: false,
        fieldName: fieldName,
        error: `填充${fieldName}时发生错误: ${error.message}`
      };
    }
  }

  // 增强的输入框可见性检查（更宽松的检测）
  function isVisibleAndEnabled(element) {
    if (!element) return false;
    
    // 基础检查 - 只排除明确不可用的
    if (element.type === 'hidden' || element.disabled) {
      return false;
    }
    
    // 只读字段在某些情况下也应该考虑（比如自动完成的用户名字段）
    // if (element.readOnly) return false; // 注释掉这个检查
    
    // 获取计算样式
    const style = window.getComputedStyle(element);
    
    // 检查显示属性 - 只排除明确隐藏的
    if (style.display === 'none') {
      return false;
    }
    
    // 对visibility: hidden 更宽松 - 有些页面使用这种方式但仍然可填充
    // if (style.visibility === 'hidden') return false; // 变为警告而不是排除
    
    // 检查透明度 - 降低阈值，允许低透明度但非零的元素
    if (parseFloat(style.opacity) < 0.01) {
      return false;
    }
    
    // 检查尺寸 - 更宽松的尺寸检查
    const rect = element.getBoundingClientRect();
    if (rect.width < 1 || rect.height < 1) {
      return false;
    }
    
    // 检查是否在视口外 - 大幅放宽限制
    if (rect.top < -5000 || rect.left < -5000 || rect.top > window.innerHeight + 5000) {
      return false;
    }
    
    // 检查父元素是否隐藏 - 只检查关键的父元素
    let parent = element.parentElement;
    let checkCount = 0;
    while (parent && parent !== document.body && checkCount < 5) { // 只检查前5个父级
      const parentStyle = window.getComputedStyle(parent);
      if (parentStyle.display === 'none') {
        return false;
      }
      parent = parent.parentElement;
      checkCount++;
    }
    
    return true;
  }
  

  
  // 判断是否可能是用户名字段（简化版，主要用于向后兼容）
  function isLikelyUsernameField(input) {
    const score = calculateUsernameFieldScore(input);
    return score > 20; // 只有评分超过20分才认为是用户名字段
  }
  
  // 从选择中填充密码（保持原有功能）
  async function fillPasswordFromSelection(passwordData) {
    const result = await attemptPasswordFill(passwordData);
    // 不在content script中显示错误通知，错误信息通过消息传递给popup处理
    // 避免与popup的通知重叠
    return result;
  }
  
  // 尝试自动填充
  function attemptAutoFill() {
    if (hasTriedAutoFill || availablePasswords.length === 0) return;
    
    hasTriedAutoFill = true;
    
    // 如果只有一个密码，直接填充
    if (availablePasswords.length === 1) {
      fillPasswordFromSelection(availablePasswords[0]);
    } else {
      // 多个密码时，选择最匹配的
      const bestMatch = findBestPasswordMatch();
      if (bestMatch) {
        fillPasswordFromSelection(bestMatch);
      }
    }
  }
  
  // 找到最佳密码匹配
  function findBestPasswordMatch() {
    if (availablePasswords.length === 0) return null;
    
    // 密码列表已经在backend中按匹配度排序，选择第一个最佳匹配
    // 优先选择有明确匹配指示的密码
    const exactMatch = availablePasswords.find(p => p.matchType === 'exact');
    if (exactMatch) return exactMatch;
    
    const partialMatch = availablePasswords.find(p => p.matchType === 'partial');
    if (partialMatch) return partialMatch;
    
    // 返回第一个密码
    return availablePasswords[0];
  }
  
  // 显示通知
  function showNotification(message, type = 'info') {
    const notification = document.createElement('div');
    
    // 设置图标和颜色方案
    const config = {
      success: { 
        bg: '#34a853', 
        icon: '✓', 
        iconBg: '#2d8f47' 
      },
      error: { 
        bg: '#ea4335', 
        icon: '✕', 
        iconBg: '#d33b2c' 
      },
      info: { 
        bg: '#4285f4', 
        icon: 'ℹ', 
        iconBg: '#3367d6' 
      }
    };
    
    const style = config[type] || config.info;
    
    notification.style.cssText = `
      position: fixed;
      top: 20px;
      right: 20px;
      background: ${style.bg};
      color: white;
      padding: 0;
      border-radius: 8px;
      z-index: 10002;
      font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
      font-size: 14px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15), 0 2px 4px rgba(0,0,0,0.1);
      min-width: 300px;
      max-width: 400px;
      opacity: 0;
      transform: translateX(100%);
      transition: all 0.3s cubic-bezier(0.2, 0, 0.2, 1);
    `;
    
    notification.innerHTML = `
      <div style="display: flex; align-items: center; padding: 16px;">
        <div style="
          width: 24px; 
          height: 24px; 
          background: ${style.iconBg}; 
          border-radius: 50%; 
          display: flex; 
          align-items: center; 
          justify-content: center; 
          margin-right: 12px;
          font-weight: bold;
          font-size: 12px;
        ">${style.icon}</div>
        <div style="flex: 1; line-height: 1.4;">
          <div style="font-weight: 500; margin-bottom: 2px;">密码管理器</div>
          <div style="font-size: 13px; opacity: 0.9;">${message}</div>
        </div>
      </div>
    `;
    
    document.body.appendChild(notification);
    
    // 动画显示
    setTimeout(() => {
      notification.style.opacity = '1';
      notification.style.transform = 'translateX(0)';
    }, 10);
    
    // 自动消失
    setTimeout(() => {
      if (notification.parentNode) {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
          if (notification.parentNode) {
            notification.remove();
          }
        }, 300);
      }
    }, 3000);
  }
  
  // 观察页面变化
  function observePageChanges() {
    const observer = new MutationObserver((mutations) => {
      mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
          // 页面有新元素添加，重新检测表单
          setTimeout(() => {
            detectAndAnalyzeForms();
          }, 100);
        }
      });
    });
    
    observer.observe(document.body, {
      childList: true,
      subtree: true
    });
  }
  
  // 页面卸载时清理
  window.addEventListener('beforeunload', () => {
    stopFormMonitoring();
  });
  
  // 初始化
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initialize);
  } else {
    initialize();
  }
  
})(); 