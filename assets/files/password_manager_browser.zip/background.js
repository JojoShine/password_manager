// 密码管理器浏览器扩展后台服务

// ==================== 日志工具 ====================
// 生产环境设置为 false，开发环境设置为 true
const ENABLE_LOGS = false;

const Logger = {
  log: (...args) => {
    if (ENABLE_LOGS) {
      console.log('[PM]', ...args);
    }
  },
  error: (...args) => {
    // 错误日志始终输出
    console.error('[PM]', ...args);
  },
  warn: (...args) => {
    if (ENABLE_LOGS) {
      console.warn('[PM]', ...args);
    }
  },
  info: (...args) => {
    if (ENABLE_LOGS) {
      console.info('[PM]', ...args);
    }
  }
};
// ================================================

// ==================== 存储工具 ====================
// 使用 chrome.storage.local 持久化服务器配置，解决 Service Worker 被杀后状态丢失问题
const StorageHelper = {
  STORAGE_KEY: 'pm_server_config',

  async save(config) {
    try {
      await chrome.storage.local.set({ [this.STORAGE_KEY]: config });
      Logger.log('服务器配置已持久化');
    } catch (e) {
      Logger.warn('持久化服务器配置失败:', e);
    }
  },

  async load() {
    try {
      const result = await chrome.storage.local.get(this.STORAGE_KEY);
      return result[this.STORAGE_KEY] || null;
    } catch (e) {
      Logger.warn('读取持久化配置失败:', e);
      return null;
    }
  },

  async clear() {
    try {
      await chrome.storage.local.remove(this.STORAGE_KEY);
      Logger.log('已清除持久化配置');
    } catch (e) {
      Logger.warn('清除持久化配置失败:', e);
    }
  }
};
// ================================================

class PasswordManagerAPI {
  constructor() {
    this.serverConfig = null;
    this.isConnected = false;
    this.lastConfigCheck = 0;
    this.configCheckInterval = 15000; // 15秒检查一次配置
    this.connectionFailureCount = 0;
    this.maxRetryInterval = 60000; // 最大重试间隔1分钟
    this.heartbeatInterval = null;
    this.heartbeatFailCount = 0;
    this.HEARTBEAT_INTERVAL = 10000; // 心跳间隔10秒
    this.MAX_HEARTBEAT_FAILURES = 3; // 最大心跳失败次数
    this.isChecking = false; // 防止并发检查

    // 异步初始化：先尝试从持久化存储恢复连接
    this._initialize();
  }

  async _initialize() {
    // 1. 先从持久化存储恢复配置
    const savedConfig = await StorageHelper.load();
    if (savedConfig) {
      this.serverConfig = savedConfig;
      Logger.log('从持久化存储恢复了服务器配置:', savedConfig.server_url);

      // 2. 立即验证连接是否仍然有效
      const isAlive = await this.pingServer();
      if (isAlive) {
        this.isConnected = true;
        this.connectionFailureCount = 0;
        Logger.log('持久化配置验证成功，连接已恢复');
      } else {
        Logger.log('持久化配置验证失败，需要重新扫描');
        this.isConnected = false;
      }
    }

    // 3. 启动心跳检测
    this.startHeartbeat();

    // 4. 启动智能检查调度
    this.scheduleNextCheck();

    // 5. 设置窗口焦点监听
    this.setupFocusListeners();

    // 6. 设置 chrome.alarms 作为可靠的后备定时器
    this._setupAlarms();
  }

  // 使用 chrome.alarms 作为 Service Worker 被杀后的可靠唤醒机制
  _setupAlarms() {
    // 创建定期唤醒闹钟，确保 Service Worker 不会长时间休眠
    chrome.alarms.create('pm_heartbeat', { periodInMinutes: 0.5 }); // 每30秒唤醒一次
    chrome.alarms.create('pm_connection_check', { periodInMinutes: 1 }); // 每60秒检查一次连接

    chrome.alarms.onAlarm.addListener((alarm) => {
      if (alarm.name === 'pm_heartbeat') {
        // Service Worker 被唤醒，检查连接状态
        if (this.isConnected) {
          this._doHeartbeat();
        } else {
          // 连接已断开，尝试重新连接
          this.checkServerConnection();
        }
      } else if (alarm.name === 'pm_connection_check') {
        this.checkServerConnection();
      }
    });

    // 监听 Service Worker 启动事件
    Logger.log('后台服务已初始化（含 chrome.alarms 保活机制）');
  }

  // 设置窗口焦点监听
  setupFocusListeners() {
    chrome.windows.onFocusChanged.addListener((windowId) => {
      if (windowId !== chrome.windows.WINDOW_ID_NONE) {
        Logger.log('浏览器窗口获得焦点，立即检查连接');
        this.checkServerConnection();
      }
    });
  }

  // 启动心跳检测
  startHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
    }

    this.heartbeatInterval = setInterval(() => {
      this._doHeartbeat();
    }, this.HEARTBEAT_INTERVAL);

    Logger.log('心跳检测已启动，间隔:', this.HEARTBEAT_INTERVAL, 'ms');
  }

  // 执行一次心跳
  async _doHeartbeat() {
    if (!this.isConnected || !this.serverConfig) return;

    try {
      const isAlive = await this.pingServer();
      if (isAlive) {
        this.heartbeatFailCount = 0;
      } else {
        this.heartbeatFailCount++;
        Logger.log('心跳失败次数:', this.heartbeatFailCount);

        if (this.heartbeatFailCount >= this.MAX_HEARTBEAT_FAILURES) {
          console.warn('心跳检测失败，标记连接断开，尝试重连');
          this.isConnected = false;
          this.connectionFailureCount++;
          await this.checkServerConnection();
        }
      }
    } catch (error) {
      console.error('心跳检测异常:', error);
      this.heartbeatFailCount++;
    }
  }

  // 停止心跳检测
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval);
      this.heartbeatInterval = null;
      Logger.log('心跳检测已停止');
    }
  }

  // 智能调度下一次检查
  scheduleNextCheck() {
    let interval = this.configCheckInterval;
    if (this.connectionFailureCount > 0) {
      interval = Math.min(
        this.configCheckInterval * Math.pow(1.3, this.connectionFailureCount - 1),
        this.maxRetryInterval
      );
    }

    setTimeout(() => {
      this.checkServerConnection().then(() => {
        this.scheduleNextCheck();
      });
    }, interval);
  }

  // 检查服务器连接
  async checkServerConnection() {
    // 防止并发检查
    if (this.isChecking) {
      Logger.log('已有检查在进行中，跳过');
      return this.isConnected;
    }

    this.isChecking = true;

    try {
      const now = Date.now();
      // 如果已连接且距离上次检查不到10秒，跳过
      if (this.isConnected && now - this.lastConfigCheck < 10000) {
        return this.isConnected;
      }
      // 如果未连接，至少等2秒再重试
      if (!this.isConnected && now - this.lastConfigCheck < 2000) {
        return this.isConnected;
      }

      this.lastConfigCheck = now;

      // 记录检查前的连接状态，用于判断是否需要通知恢复
      const wasDisconnected = !this.isConnected;

      // 读取服务器配置
      const config = await this.readServerConfig();
      if (!config) {
        this.isConnected = false;
        this.connectionFailureCount++;
        Logger.log('连接失败次数:', this.connectionFailureCount);
        return false;
      }

      // 检查配置是否变化
      const configChanged = !this.serverConfig ||
                           this.serverConfig.server_url !== config.server_url ||
                           this.serverConfig.token !== config.token;

      if (configChanged) {
        Logger.log('检测到服务器配置变化，更新配置');
        this.serverConfig = config;
        // 持久化新配置
        await StorageHelper.save(config);
      }

      // 测试连接
      const isAlive = await this.pingServer();
      this.isConnected = isAlive;

      if (isAlive) {
        this.connectionFailureCount = 0;
        this.heartbeatFailCount = 0;
        Logger.log('连接成功！');

        // 确保持久化
        await StorageHelper.save(config);

        // 如果之前是断开状态或配置发生了变化，通知所有标签页
        if (wasDisconnected || configChanged) {
          this.notifyConnectionRestored();
        }
      } else {
        this.connectionFailureCount++;
        Logger.log('连接失败次数:', this.connectionFailureCount);
      }

      return this.isConnected;
    } catch (error) {
      console.error('检查服务器连接失败:', error);
      this.isConnected = false;
      this.connectionFailureCount++;
      return false;
    } finally {
      this.isChecking = false;
    }
  }

  // 通知连接恢复
  notifyConnectionRestored() {
    Logger.log('通知所有标签页连接已恢复');
    chrome.tabs.query({}, (tabs) => {
      tabs.forEach(tab => {
        if (tab.id) {
          chrome.tabs.sendMessage(tab.id, {
            action: 'connectionRestored'
          }).catch(() => {});
        }
      });
    });
  }

  // 读取服务器配置 - 使用并行端口扫描
  async readServerConfig() {
    try {
      Logger.log('开始扫描端口...');

      // 构建优先级端口列表
      const priorityPorts = [];

      // 1. 优先使用上次成功的端口（从持久化存储）
      const savedConfig = await StorageHelper.load();
      if (savedConfig && savedConfig.server_url) {
        try {
          const lastPort = parseInt(savedConfig.server_url.split(':')[2]);
          if (lastPort >= 5000 && lastPort < 6000) {
            priorityPorts.push(lastPort);
          }
        } catch (e) {}
      }

      // 2. 如果内存中有配置，也优先使用
      if (this.serverConfig && this.serverConfig.server_url) {
        try {
          const memPort = parseInt(this.serverConfig.server_url.split(':')[2]);
          if (memPort >= 5000 && memPort < 6000 && !priorityPorts.includes(memPort)) {
            priorityPorts.unshift(memPort); // 内存中的配置优先级最高
          }
        } catch (e) {}
      }

      // 3. 添加固定端口（Flutter app 优先使用的端口）
      [5000, 5001, 5002, 5003, 5004, 5005].forEach(port => {
        if (!priorityPorts.includes(port)) {
          priorityPorts.push(port);
        }
      });

      // 第一步：并行检查优先级端口
      Logger.log('并行检查优先级端口:', priorityPorts);
      const priorityResults = await Promise.all(
        priorityPorts.map(port => this.tryPort(port))
      );

      for (const result of priorityResults) {
        if (result !== null) {
          Logger.log('在优先级端口找到服务器');
          return result;
        }
      }

      // 第二步：并行批量扫描剩余端口
      Logger.log('优先级端口未找到，开始批量扫描...');
      const batchSize = 50; // 每批50个端口并行

      for (let startPort = 5000; startPort < 6000; startPort += batchSize) {
        // 跳过已在优先级列表中检查过的端口
        const portsToCheck = [];
        for (let p = startPort; p < startPort + batchSize && p < 6000; p++) {
          if (!priorityPorts.includes(p)) {
            portsToCheck.push(p);
          }
        }

        if (portsToCheck.length === 0) continue;

        const results = await Promise.all(
          portsToCheck.map(port => this.tryPort(port))
        );

        for (const result of results) {
          if (result !== null) {
            Logger.log('在批量扫描中找到服务器');
            return result;
          }
        }
      }

      Logger.log('未找到可用的配置服务器');
      return null;
    } catch (error) {
      console.error('读取服务器配置失败:', error);
      return null;
    }
  }

  // 尝试单个端口（并行安全）
  async tryPort(port) {
    try {
      const configPath = `http://127.0.0.1:${port}/config`;
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 1500); // 1.5秒超时

      const response = await fetch(configPath, {
        signal: controller.signal,
        method: 'GET'
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        const configText = await response.text();
        const configResponse = JSON.parse(configText);

        if (configResponse.success && configResponse.data) {
          return configResponse.data;
        } else {
          return configResponse;
        }
      }
      return null;
    } catch (e) {
      return null;
    }
  }

  // Ping服务器
  async pingServer() {
    if (!this.serverConfig) return false;

    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 3000);

      const response = await fetch(`${this.serverConfig.server_url}/api/ping`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.serverConfig.token}`,
          'Content-Type': 'application/json'
        },
        signal: controller.signal,
        mode: 'cors'
      });

      clearTimeout(timeoutId);

      if (response.ok) {
        const data = await response.json();
        return data.success && data.data.message === 'pong';
      }

      return false;
    } catch (error) {
      return false;
    }
  }

  // 调用API
  async callAPI(endpoint, method = 'GET', data = null) {
    // 在调用API前确保连接
    if (!this.isConnected) {
      Logger.log('连接未建立，尝试重新连接...');
      await this.checkServerConnection();
      if (!this.isConnected) {
        throw new Error('无法连接到密码管理器应用，请确保应用正在运行');
      }
    }

    const url = `${this.serverConfig.server_url}${endpoint}`;
    const options = {
      method,
      headers: {
        'Authorization': `Bearer ${this.serverConfig.token}`,
        'Content-Type': 'application/json'
      }
    };

    if (data && (method === 'POST' || method === 'PUT')) {
      options.body = JSON.stringify(data);
    }

    try {
      const response = await fetch(url, options);
      const result = await response.json();

      if (!response.ok) {
        throw new Error(result.error || `HTTP ${response.status}`);
      }

      // API调用成功，重置失败计数
      this.connectionFailureCount = 0;

      return result.data;
    } catch (error) {
      console.error('API调用失败:', error);
      // 如果是连接错误，标记为断开并尝试重连
      if (error.name === 'TypeError' || error.message.includes('Failed to fetch')) {
        this.isConnected = false;
        this.connectionFailureCount++;

        // 异步尝试重连
        setTimeout(() => {
          this.checkServerConnection();
        }, 1000);
      }
      throw error;
    }
  }

  // 搜索密码
  async searchPasswords(query = '') {
    return this.callAPI(`/api/passwords?q=${encodeURIComponent(query)}`);
  }

  // 根据域名获取密码
  async getPasswordsByDomain(domain) {
    Logger.log('[API] 根据域名获取密码:', {
      domain: domain,
      url: `/api/passwords/domain?domain=${encodeURIComponent(domain)}`
    });

    const result = await this.callAPI(`/api/passwords/domain?domain=${encodeURIComponent(domain)}`);

    const passwords = result && result.passwords ? result.passwords : [];

    Logger.log('[API] 域名密码查询结果:', {
      domain: domain,
      foundPasswords: passwords.length,
      total: result ? result.total : 0,
    });

    return passwords;
  }

  // 保存密码
  async savePassword(passwordData) {
    Logger.log('[API] 调用保存密码接口:', {
      endpoint: '/api/passwords',
      method: 'POST',
      hasPasswordData: !!passwordData,
      dataKeys: passwordData ? Object.keys(passwordData) : [],
    });

    try {
      const website = passwordData.website || '';
      const username = passwordData.username || '';

      if (website && username) {
        const existingPasswords = await this.getPasswordsByDomain(website);

        if (existingPasswords && existingPasswords.length > 0) {
          const duplicate = existingPasswords.find(p =>
            p.username === username && p.password === passwordData.password
          );

          if (duplicate) {
            return {
              success: false,
              message: `该账号密码已保存过（标题: "${duplicate.title}"），无需重复保存`,
              duplicate: true,
              existingEntry: {
                id: duplicate.id,
                title: duplicate.title,
                username: duplicate.username
              }
            };
          }

          const sameUsername = existingPasswords.find(p =>
            p.username === username && p.password !== passwordData.password
          );

          if (sameUsername) {
            return {
              success: false,
              message: `该网站已保存过此用户名的密码，但密码不同。建议更新现有记录（标题: "${sameUsername.title}"）`,
              duplicate: false,
              differentPassword: true,
              existingEntry: {
                id: sameUsername.id,
                title: sameUsername.title,
                username: sameUsername.username
              }
            };
          }
        }
      }

      const result = await this.callAPI('/api/passwords', 'POST', passwordData);
      return result;
    } catch (error) {
      console.error('[API] 保存密码失败:', error);
      throw error;
    }
  }

  // 更新密码
  async updatePassword(passwordData) {
    return this.callAPI('/api/passwords', 'PUT', passwordData);
  }

  // 删除密码
  async deletePassword(id) {
    return this.callAPI(`/api/passwords?id=${id}`, 'DELETE');
  }
}

// 创建API实例
const passwordManagerAPI = new PasswordManagerAPI();

// 监听来自content script和popup的消息
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  handleMessage(request, sender, sendResponse);
  return true;
});

// 处理消息
async function handleMessage(request, sender, sendResponse) {
  try {
    const { action, data } = request;
    let result;

    switch (action) {
      case 'checkConnection':
      case 'checkServerConnection':
        result = await passwordManagerAPI.checkServerConnection();
        break;

      case 'searchPasswords':
        result = await passwordManagerAPI.searchPasswords(data.query);
        break;

      case 'getPasswordsByDomain':
        result = await passwordManagerAPI.getPasswordsByDomain(data.domain);

        try {
          if (sender && sender.tab && sender.tab.id) {
            if (result && result.length > 0) {
              await updateExtensionBadge(sender.tab.id, result.length);
            } else {
              await clearExtensionBadge(sender.tab.id);
            }
          }
        } catch (error) {
          console.error('更新图标状态失败:', error);
        }
        break;

      case 'savePassword':
        Logger.log('[BACKGROUND] 接收到保存密码请求');
        try {
          result = await passwordManagerAPI.savePassword(data.password);

          if (sender && sender.tab && sender.tab.id && data.password && data.password.website) {
            const domain = extractDomain(data.password.website);
            if (domain) {
              const updatedPasswords = await passwordManagerAPI.getPasswordsByDomain(domain);
              if (updatedPasswords && updatedPasswords.length > 0) {
                await updateExtensionBadge(sender.tab.id, updatedPasswords.length);
              }
            }
          }
        } catch (error) {
          console.error('[BACKGROUND] 保存密码失败:', error);
          throw error;
        }
        break;

      case 'updatePassword':
        result = await passwordManagerAPI.updatePassword(data.password);
        break;

      case 'deletePassword':
        result = await passwordManagerAPI.deletePassword(data.id);
        break;

      case 'getConnectionStatus':
        result = {
          isConnected: passwordManagerAPI.isConnected,
          serverUrl: passwordManagerAPI.serverConfig ? passwordManagerAPI.serverConfig.server_url : null
        };
        break;

      default:
        throw new Error(`未知操作: ${action}`);
    }

    sendResponse({ success: true, data: result });
  } catch (error) {
    console.error('处理消息失败:', error);
    sendResponse({ success: false, error: error.message });
  }
}

// 提取域名工具函数
function extractDomain(url) {
  try {
    if (!url) return null;

    let cleanUrl = url.trim();

    if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
      const ipRegex = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?$/;
      if (ipRegex.test(cleanUrl)) {
        return cleanUrl.split(':')[0];
      }
      cleanUrl = 'https://' + cleanUrl;
    }

    const urlObj = new URL(cleanUrl);
    return urlObj.hostname.toLowerCase();
  } catch (error) {
    let cleanUrl = url ? url.trim() : '';
    cleanUrl = cleanUrl.replace(/^https?:\/\//, '').split('/')[0].split('?')[0];
    cleanUrl = cleanUrl.split(':')[0];

    const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
    if (ipRegex.test(cleanUrl)) {
      return cleanUrl;
    }

    const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*\.([a-zA-Z]{2,}|[a-zA-Z0-9-]*[a-zA-Z0-9])$/;
    if (domainRegex.test(cleanUrl)) {
      return cleanUrl.toLowerCase();
    }

    return cleanUrl.toLowerCase();
  }
}

// 标签页处理缓存
const tabDomainCache = new Map();

// 更新扩展图标标记
async function updateExtensionBadge(tabId, passwordCount) {
  try {
    await chrome.action.setBadgeText({
      text: passwordCount.toString(),
      tabId: tabId
    });

    await chrome.action.setBadgeBackgroundColor({
      color: '#34a853',
      tabId: tabId
    });

    await chrome.action.setBadgeTextColor({
      color: '#ffffff',
      tabId: tabId
    });
  } catch (error) {
    console.error('更新扩展图标标记失败:', error);
  }
}

// 清除扩展图标标记
async function clearExtensionBadge(tabId) {
  try {
    await chrome.action.setBadgeText({
      text: '',
      tabId: tabId
    });
  } catch (error) {
    console.error('清除扩展图标标记失败:', error);
  }
}

// 监听标签页更新
chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.startsWith('http')) {
    const domain = extractDomain(tab.url);
    if (domain) {
      const cacheKey = `${tabId}-${domain}`;
      const lastCheck = tabDomainCache.get(cacheKey);
      const now = Date.now();

      if (lastCheck && (now - lastCheck) < 30000) {
        return;
      }

      tabDomainCache.set(cacheKey, now);

      try {
        const passwords = await passwordManagerAPI.getPasswordsByDomain(domain);

        if (passwords && passwords.length > 0) {
          await updateExtensionBadge(tabId, passwords.length);
        } else {
          await clearExtensionBadge(tabId);
        }
      } catch (error) {
        // 静默处理
      }
    }
  }
});

// 监听标签页激活
chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (tab.url && tab.url.startsWith('http')) {
      const domain = extractDomain(tab.url);
      if (domain) {
        const passwords = await passwordManagerAPI.getPasswordsByDomain(domain);
        if (passwords && passwords.length > 0) {
          await updateExtensionBadge(activeInfo.tabId, passwords.length);
        } else {
          await clearExtensionBadge(activeInfo.tabId);
        }
      }
    }
  } catch (error) {
    console.error('标签页激活时更新图标失败:', error);
  }
});

// 清理标签页缓存
chrome.tabs.onRemoved.addListener((tabId) => {
  for (const [key] of tabDomainCache.entries()) {
    if (key.startsWith(`${tabId}-`)) {
      tabDomainCache.delete(key);
    }
  }
});

// 启动时初始化
chrome.tabs.query({ active: true, currentWindow: true }, async (tabs) => {
  if (tabs.length > 0) {
    const tab = tabs[0];
    if (tab.url && tab.url.startsWith('http')) {
      const domain = extractDomain(tab.url);
      if (domain && passwordManagerAPI.isConnected) {
        try {
          const passwords = await passwordManagerAPI.getPasswordsByDomain(domain);
          if (passwords && passwords.length > 0) {
            await updateExtensionBadge(tab.id, passwords.length);
          } else {
            await clearExtensionBadge(tab.id);
          }
        } catch (error) {
          console.error('初始化图标状态失败:', error);
        }
      }
    }
  }
});

Logger.log('密码管理器浏览器扩展后台服务已启动');
