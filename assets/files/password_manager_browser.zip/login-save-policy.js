(function(root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) {
    module.exports = api;
  } else {
    root.LoginSavePolicy = api;
  }
})(typeof globalThis !== 'undefined' ? globalThis : this, function() {
  'use strict';

  const PENDING_LOGIN_TTL_MS = 30000;
  const LOGIN_SUCCESS_STABILITY_MS = 2000;

  function evaluateLoginResult({
    pending,
    now,
    hasVisiblePasswordField,
    passwordFieldHiddenForMs = 0
  }) {
    if (!pending) return 'none';

    if (now - pending.submittedAt > PENDING_LOGIN_TTL_MS) {
      return 'expired';
    }

    if (hasVisiblePasswordField ||
        passwordFieldHiddenForMs < LOGIN_SUCCESS_STABILITY_MS) {
      return 'waiting';
    }

    return 'confirmed';
  }

  function createLoginSaveFlow({
    stagePending,
    getPending,
    consumePending,
    discardPending,
    showPrompt,
    now = () => Date.now()
  }) {
    return {
      async submit(pending) {
        if (!pending || !pending.username || !pending.password) return false;
        await stagePending(pending);
        return true;
      },

      async evaluate({ hasVisiblePasswordField, passwordFieldHiddenForMs = 0 }) {
        const pending = await getPending();
        const result = evaluateLoginResult({
          pending,
          now: now(),
          hasVisiblePasswordField,
          passwordFieldHiddenForMs
        });

        if (result === 'expired') {
          await discardPending();
        } else if (result === 'confirmed') {
          const confirmed = await consumePending();
          if (confirmed) showPrompt(confirmed);
        }

        return result;
      }
    };
  }

  return {
    PENDING_LOGIN_TTL_MS,
    LOGIN_SUCCESS_STABILITY_MS,
    evaluateLoginResult,
    createLoginSaveFlow
  };
});
