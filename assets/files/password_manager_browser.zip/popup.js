// Lockora弹窗脚本

const Logger = Object.freeze({
  log() {},
  error() {},
  warn() {},
  info() {}
});

// Lockora弹窗脚本
class PasswordManagerPopup {
  constructor() {
    this.passwords = [];
    this.initializeElements();
    this.bindEvents();
    this.setupVisibilityHandler();
    this.initialize();
  }

  // 初始化DOM元素引用
  initializeElements() {
    this.elements = {
      loadingState: document.getElementById('loadingState'),
      disconnectState: document.getElementById('disconnectState'),
      mainInterface: document.getElementById('mainInterface'),
      statusIndicator: document.getElementById('statusIndicator'),
      statusText: document.getElementById('statusText'),
      currentDomainInfo: document.getElementById('currentDomainInfo'),
      currentDomainValue: document.getElementById('currentDomainValue'),
      passwordCount: document.getElementById('passwordCount'),
      passwordCountNumber: document.getElementById('passwordCountNumber'),
      passwordList: document.getElementById('passwordList'),
      emptyState: document.getElementById('emptyState'),
      refreshBtn: document.getElementById('refreshBtn'),
      retryBtn: document.getElementById('retryBtn'),
      footerText: document.getElementById('footerText'),
      portInfo: document.getElementById('portInfo')
    };
  }

  // 绑定事件监听器
  bindEvents() {
    this.elements.refreshBtn.addEventListener('click', () => {
      this.refreshPasswords();
    });

    this.elements.retryBtn.addEventListener('click', () => {
      this.initialize();
    });
  }

  // 设置页面可见性处理
  setupVisibilityHandler() {
    // 监听页面可见性变化
    document.addEventListener('visibilitychange', () => {
      if (document.visibilityState === 'visible') {
        Logger.log('弹窗变为可见，检查是否需要刷新数据');
        // 如果当前状态是断开连接，尝试重新初始化
        if (this.elements.mainInterface.style.display === 'none') {
          Logger.log('当前处于断开状态，尝试重新初始化');
          this.initialize();
        }
      }
    });

    // 监听窗口焦点事件
    window.addEventListener('focus', () => {
      Logger.log('弹窗获得焦点');
      // 可以在这里添加需要的刷新逻辑
    });
  }

  // 初始化弹窗
  async initialize() {
    Logger.log('Lockora弹窗初始化...');
    this.showLoadingState();

    // 重置状态
    this.passwords = [];
    this.currentPageInfo = null;

    try {
      // 获取当前页面信息
      this.currentPageInfo = await this.getCurrentPageInfo();
      Logger.log('当前页面信息:', this.currentPageInfo);
      
      const isConnected = await this.connectForUserAttempt();
      
      if (isConnected) {
        // 连接状态已在 establishConnection 中更新
        // 等待一小段时间确保连接稳定
        await new Promise(resolve => setTimeout(resolve, 100));
        // 只加载匹配当前页面的密码
        await this.loadMatchingPasswords();
      } else {
        Logger.log('连接失败，显示重试界面');
        this.showDisconnectedState();
      }
    } catch (error) {
      Logger.error('初始化失败:', error);
      this.showDisconnectedState(error.message);
    }
  }

  // 获取当前页面信息
  async getCurrentPageInfo() {
    try {
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const currentTab = tabs[0];
      
      if (!currentTab || !currentTab.url) {
        return null;
      }
      
      const domain = this.extractDomain(currentTab.url);
      const ip = this.extractIP(currentTab.url);
      
      return {
        url: currentTab.url,
        domain: domain,
        ip: ip,
        title: currentTab.title
      };
    } catch (error) {
      Logger.error('获取当前页面信息失败:', error);
      return null;
    }
  }

  // 主动建立连接
  async establishConnection({ force = false } = {}) {
    Logger.log('主动建立服务器连接...');
    
    try {
      // 首先检查现有连接
      const statusResponse = await chrome.runtime.sendMessage({
        action: 'getConnectionStatus'
      });

      if (statusResponse.success && statusResponse.data.isConnected) {
        Logger.log('服务器已连接');
        // 提取端口号
        const serverUrl = statusResponse.data.serverUrl;
        const port = this.extractPortFromUrl(serverUrl);
        this.updateConnectionStatus(true, null, port);
        return true;
      }

      // 尝试建立新连接
      const connectResponse = await chrome.runtime.sendMessage({
        action: 'checkServerConnection',
        data: { force }
      });

      if (!connectResponse.success) throw new Error(connectResponse.error);
      if (connectResponse.success) {
        // 再次确认连接状态
        const finalStatusResponse = await chrome.runtime.sendMessage({
          action: 'getConnectionStatus'
        });

        if (finalStatusResponse.success && finalStatusResponse.data.isConnected) {
          Logger.log('服务器连接成功');
          const serverUrl = finalStatusResponse.data.serverUrl;
          const port = this.extractPortFromUrl(serverUrl);
          this.updateConnectionStatus(true, null, port);
          return true;
        }
      }
      
      Logger.log('服务器连接失败');
      return false;
    } catch (error) {
      Logger.error('建立连接失败:', error);
      throw error;
    }
  }

  async connectForUserAttempt() {
    return this.establishConnection({ force: true });
  }

  // 更新连接状态显示
  updateConnectionStatus(isConnected, serverUrl = null, port = null) {
    if (isConnected) {
      this.elements.statusIndicator.className = 'status-indicator status-connected';
      this.elements.statusText.textContent = '已连接';
      
      // 显示端口信息
      if (port) {
        this.elements.portInfo.textContent = `端口 ${port}`;
        this.elements.portInfo.classList.add('visible');
      }
      
      if (serverUrl) {
        const url = new URL(serverUrl);
        this.elements.footerText.textContent = `连接到 ${url.host}`;
      }
    } else {
      this.elements.statusIndicator.className = 'status-indicator status-disconnected';
      this.elements.statusText.textContent = '连接失败';
      this.elements.portInfo.classList.remove('visible');
    }
  }

  // 检查连接状态（保留用于兼容性）
  async checkConnection() {
    return await this.establishConnection();
  }

  // 加载匹配当前页面的密码
  async loadMatchingPasswords() {
    Logger.log('开始加载匹配密码...');
    
    try {
      // 确保有页面信息
      if (!this.currentPageInfo) {
        Logger.log('没有当前页面信息，重新获取...');
        this.currentPageInfo = await this.getCurrentPageInfo();
      }

      if (!this.currentPageInfo) {
        Logger.log('无法获取当前页面信息，显示空状态');
        this.passwords = [];
        this.renderPasswordList();
        this.showMainInterface();
        return;
      }

      const { url, domain, ip } = this.currentPageInfo;
      Logger.log(`页面信息确认: URL=${url}, 域名=${domain}, IP=${ip}`);

      // 显示当前域名信息
      this.showCurrentDomainInfo(url, domain, ip);

      let matchingPasswords = [];

      // 如果有域名或IP，尝试精确匹配
      if (domain || ip) {
        Logger.log(`正在查找匹配域名/IP的密码: 域名=${domain}, IP=${ip}`);
        
        const searchTarget = domain || ip;
        Logger.log(`搜索目标: ${searchTarget}`);
        
        const domainResponse = await chrome.runtime.sendMessage({
          action: 'getPasswordsByDomain',
          data: { domain: searchTarget }
        });

        Logger.log('域名API响应:', domainResponse);

        if (domainResponse.success) {
          const domainPasswords = domainResponse.data || [];
          Logger.log(`通过域名API找到 ${domainPasswords.length} 个密码`);
          
          if (domainPasswords.length > 0) {
            Logger.log('找到的密码列表:', domainPasswords.map(p => ({
              title: p.title,
              website: p.website,
              username: p.username
            })));
          }
          
          // 信任后端匹配结果，不再进行严格的前端过滤
          // 后端的匹配逻辑已经考虑了各种情况，包括域名、IP匹配
          Logger.log('🎯 信任后端匹配结果，直接使用返回的密码列表');
          matchingPasswords = domainPasswords;
          
          // 可选：进行宽松的验证，只检查明显不匹配的情况
          if (matchingPasswords.length > 0) {
            Logger.log('✅ 直接使用后端匹配的密码:', matchingPasswords.map(p => ({
              title: p.title,
              website: p.website,
              username: p.username
            })));
          }
        } else {
          throw new Error(domainResponse.error || '加载密码失败，请重试');
        }
      } else {
        Logger.log('没有有效的域名或IP，无法进行匹配');
      }

      Logger.log(`最终匹配的密码数量: ${matchingPasswords.length}`);
      if (matchingPasswords.length > 0) {
        Logger.log('匹配的密码:', matchingPasswords.map(p => ({
          title: p.title,
          username: p.username,
          website: p.website
        })));
      }
      
      this.passwords = matchingPasswords;
      this.renderPasswordList();
      this.showMainInterface();
    } catch (error) {
      Logger.error('加载匹配密码失败:', error);
      this.passwords = [];
      this.renderPasswordList();
      this.showDisconnectedState(error.message);
    }
  }

  // 加载密码列表（保留用于兼容性，现在调用新方法）
  async loadPasswords() {
    await this.loadMatchingPasswords();
  }

  // 刷新密码列表
  async refreshPasswords() {
    Logger.log('开始刷新密码列表...');
    
    // 显示刷新动画
    this.elements.refreshBtn.classList.add('refreshing');
    
    try {
      // 重新获取当前页面信息
      this.currentPageInfo = await this.getCurrentPageInfo();
      Logger.log('刷新时的当前页面信息:', this.currentPageInfo);
      
      // 检查连接状态
      const isConnected = await this.connectForUserAttempt();

      if (!isConnected) {
        this.showNotification('连接失败，请检查Lockora应用', 'error');
        return;
      }
      
      // 等待连接稳定
      await new Promise(resolve => setTimeout(resolve, 100));
      
      await this.loadMatchingPasswords();
      
      // 根据结果显示不同消息
      if (this.passwords.length > 0) {
        this.showNotification(`已刷新，找到 ${this.passwords.length} 个匹配密码`, 'success');
      } else {
        this.showNotification('已刷新，未找到匹配密码', 'info');
      }
    } catch (error) {
      Logger.error('刷新失败:', error);
      this.showNotification('刷新失败，请重试', 'error');
    } finally {
      // 移除刷新动画
      setTimeout(() => {
        this.elements.refreshBtn.classList.remove('refreshing');
      }, 1000);
    }
  }

  // 渲染密码列表
  renderPasswordList() {
    Logger.log(`开始渲染密码列表，密码数量: ${this.passwords.length}`);
    
    const list = this.elements.passwordList;
    const emptyState = this.elements.emptyState;
    const passwordCount = this.elements.passwordCount;
    const passwordCountNumber = this.elements.passwordCountNumber;

    // 确保所有元素都存在
    if (!list || !emptyState || !passwordCount || !passwordCountNumber) {
      Logger.error('找不到必要的DOM元素');
      return;
    }

    if (this.passwords.length === 0) {
      Logger.log('显示空状态');
      list.style.display = 'none';
      passwordCount.style.display = 'none';
      emptyState.style.display = 'flex'; // 使用flex以正确居中显示
      return;
    }

    Logger.log('显示密码列表');
    list.style.display = 'block';
    passwordCount.style.display = 'block';
    emptyState.style.display = 'none';

    // 更新密码数量
    passwordCountNumber.textContent = this.passwords.length;

    // 清空并重新填充列表
    list.innerHTML = '';

    this.passwords.forEach((password, index) => {
      try {
        const passwordItem = this.createPasswordItem(password, index);
        list.appendChild(passwordItem);
        Logger.log(`添加密码项 ${index + 1}: ${password.title || password.website}`);
      } catch (error) {
        Logger.error(`创建密码项 ${index} 失败:`, error, password);
      }
    });
    
    Logger.log('密码列表渲染完成');
  }

  // 创建密码项元素
  createPasswordItem(password, index) {
    const div = document.createElement('div');
    div.className = 'password-item';
    
    const title = password.title || password.website || '未知网站';
    const subtitle = password.username || password.email || '无用户名';
    // 使用标题首字母作为简单标识
    const initial = title.charAt(0).toUpperCase();
    
    const initialElement = document.createElement('div');
    initialElement.className = 'password-initial';
    initialElement.textContent = initial;

    const info = document.createElement('div');
    info.className = 'password-info';
    const titleElement = document.createElement('div');
    titleElement.className = 'password-title';
    titleElement.title = title;
    titleElement.textContent = title;
    const subtitleElement = document.createElement('div');
    subtitleElement.className = 'password-subtitle';
    subtitleElement.title = subtitle;
    subtitleElement.textContent = subtitle;
    info.append(titleElement, subtitleElement);

    const actions = document.createElement('div');
    actions.className = 'password-actions';
    for (const [action, label, tooltip] of [
      ['copy', '复制', '复制密码'],
      ['fill', '填充', '自动填充']
    ]) {
      const button = document.createElement('button');
      button.className = `action-btn ${action}-btn`;
      button.title = tooltip;
      button.dataset.action = action;
      button.dataset.index = String(index);
      button.textContent = label;
      actions.appendChild(button);
    }

    div.append(initialElement, info, actions);

    // 绑定事件
    div.addEventListener('click', (e) => {
      if (e.target.classList.contains('action-btn')) {
        const action = e.target.dataset.action;
        const index = parseInt(e.target.dataset.index);
        this.handlePasswordAction(action, this.passwords[index]);
      } else {
        // 点击密码项默认复制密码
        this.handlePasswordAction('copy', password);
      }
    });

    return div;
  }

  // 处理密码操作
  async handlePasswordAction(action, password) {
    try {
      switch (action) {
        case 'copy':
          await this.copyPassword(password);
          break;
        case 'fill':
          await this.fillPassword(password);
          break;
      }
    } catch (error) {
      Logger.error('密码操作失败:', error);
      this.showNotification('操作失败: ' + error.message, 'error');
    }
  }

  // 复制密码
  async copyPassword(password) {
    try {
      await navigator.clipboard.writeText(password.password);
      this.showNotification('密码已复制到剪贴板', 'success');
    } catch (error) {
      // 降级处理：使用传统方法复制
      const textArea = document.createElement('textarea');
      textArea.value = password.password;
      document.body.appendChild(textArea);
      textArea.select();
      document.execCommand('copy');
      document.body.removeChild(textArea);
      this.showNotification('密码已复制到剪贴板', 'success');
    }
  }

  // 自动填充密码
  async fillPassword(password) {
    Logger.log('🚀 [POPUP] 开始自动填充密码流程');
    Logger.log('📦 [POPUP] 密码数据:', {
      title: password.title || '(无标题)',
      website: password.website || '(无网站)',
      username: password.username ? `[长度: ${password.username.length}]` : '(无用户名)',
      hasPassword: !!password.password
    });
    
    try {
      // 获取当前活动标签页
      Logger.log('🔍 [POPUP] 获取当前标签页...');
      const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
      const activeTab = tabs[0];

      if (!activeTab || !activeTab.id) {
        throw new Error('无法获取当前标签页');
      }
      
      Logger.log('📋 [POPUP] 目标标签页:', {
        id: activeTab.id,
        url: activeTab.url,
        title: activeTab.title
      });

      // 向content script发送填充消息并等待结果
      Logger.log('📤 [POPUP] 发送填充消息到content script...');
      const response = await chrome.tabs.sendMessage(activeTab.id, {
        action: 'fillPassword',
        data: { password }
      });

      Logger.log('📨 [POPUP] 收到content script响应:', response);

      if (response && response.success) {
        // 填充成功，直接关闭弹窗
        setTimeout(() => {
          window.close();
        }, 1500);
      } else {
        // 填充失败，显示具体错误信息
        const errorMessage = response?.error || '自动填充失败';
        Logger.error('填充失败:', errorMessage);
        
                         // 根据错误类型显示不同的友好提示
        if (errorMessage.includes('页面没有输入框') || errorMessage.includes('不是登录页面') || errorMessage.includes('登录框可能被隐藏')) {
          // 检测失败的情况 - 显示来自content script的具体友好错误信息
          Logger.log('🚫 [POPUP] 页面检测失败，不执行自动复制');
          Logger.log('📊 [POPUP] 检测详情:', response?.details);
          
          // 直接显示content script返回的友好错误信息
          this.showNotification(errorMessage, 'error');
          
          // 如果有详细信息，在控制台显示，但不提示用户查看
          if (response?.details) {
            Logger.log('📋 [POPUP] 页面输入框检测详情:', response.details);
          }
          
          // 不自动复制密码，严格按照用户要求
        } else if (errorMessage.includes('密码可能已填入但检测不到')) {
          // 填充成功但验证失败的情况
          Logger.log('⚠️ [POPUP] 填充后验证失败，不执行自动复制');
          this.showNotification(errorMessage, 'warning');
        } else if (errorMessage.includes('无法向密码框输入内容')) {
          // 密码字段填充失败
          Logger.log('⚠️ [POPUP] 密码字段填充失败');
          this.showNotification(errorMessage, 'error');
        } else if (errorMessage.includes('填充时遇到技术问题')) {
          // 技术异常
          Logger.log('⚠️ [POPUP] 技术异常');
          this.showNotification(errorMessage, 'error');
        } else {
          // 其他未分类的错误，使用通用友好提示
          Logger.log('⚠️ [POPUP] 其他填充错误，不执行自动复制');
          this.showNotification('自动填充遇到问题，建议手动操作', 'error');
        }
      }
    } catch (error) {
      Logger.error('🚫 [POPUP] 自动填充过程中发生错误:', error);
      
      // 检查是否是content script不存在的错误
      if (error.message && error.message.includes('Could not establish connection')) {
        Logger.log('🚫 [POPUP] Content script连接失败，不执行自动复制');
        this.showNotification('页面还在加载，请稍后重试', 'warning');
      } else {
        Logger.log('🚫 [POPUP] 其他填充错误，不执行自动复制');
        this.showNotification('网络连接有问题，请稍后重试', 'error');
      }
      
      // 用户明确表示不需要在没有输入框时自动复制密码
      // 因为有专门的复制按钮，所以移除自动复制逻辑
    }
  }



  // 从 URL 中提取端口号
  extractPortFromUrl(url) {
    if (!url) return null;
    try {
      const parsed = new URL(url);
      return parsed.port || null;
    } catch (e) {
      return null;
    }
  }

  // 提取域名
  extractDomain(url) {
    try {
      if (!url) return null;
      
      let cleanUrl = url.trim();
      
      // 如果不是完整URL，尝试添加协议
      if (!cleanUrl.startsWith('http://') && !cleanUrl.startsWith('https://')) {
        // 检查是否是IP地址
        const ipRegex = /^(\d{1,3}\.){3}\d{1,3}(:\d+)?$/;
        if (ipRegex.test(cleanUrl)) {
          return cleanUrl.split(':')[0]; // 移除端口号，只返回IP地址
        }
        cleanUrl = 'https://' + cleanUrl;
      }
      
      const urlObj = new URL(cleanUrl);
      return urlObj.hostname.toLowerCase();
    } catch (error) {
      // 如果URL解析失败，尝试直接提取域名或IP
      let cleanUrl = url ? url.trim() : '';
      
      // 移除协议和路径，只保留域名/IP
      cleanUrl = cleanUrl.replace(/^https?:\/\//, '').split('/')[0].split('?')[0];
      
      // 移除端口号
      cleanUrl = cleanUrl.split(':')[0];
      
      // 检查是否是IP地址
      const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
      if (ipRegex.test(cleanUrl)) {
        return cleanUrl;
      }
      
      // 检查是否是有效域名
      const domainRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*\.([a-zA-Z]{2,}|[a-zA-Z0-9-]*[a-zA-Z0-9])$/;
      if (domainRegex.test(cleanUrl)) {
        return cleanUrl.toLowerCase();
      }
      
      return cleanUrl.toLowerCase(); // 返回处理后的字符串，即使不是标准域名
    }
  }

  // 显示加载状态
  showLoadingState() {
    this.elements.loadingState.style.display = 'block';
    this.elements.disconnectState.style.display = 'none';
    this.elements.mainInterface.style.display = 'none';
    
    this.elements.statusIndicator.className = 'status-indicator status-connecting';
    this.elements.statusText.textContent = '连接中...';
  }

  // 显示连接状态
  showConnectedState(serverUrl) {
    this.elements.loadingState.style.display = 'none';
    this.elements.disconnectState.style.display = 'none';
    this.elements.mainInterface.style.display = 'block';
    
    this.elements.statusIndicator.className = 'status-indicator status-connected';
    this.elements.statusText.textContent = '已连接';
    
    if (serverUrl) {
      const url = new URL(serverUrl);
      this.elements.footerText.textContent = `连接到 ${url.host}`;
    }
  }

  // 显示断连状态
  showDisconnectedState(message = '请确保Lockora应用正在运行并已解锁') {
    this.elements.disconnectState.querySelector('p').textContent = message;
    this.elements.loadingState.style.display = 'none';
    this.elements.disconnectState.style.display = 'block';
    this.elements.mainInterface.style.display = 'none';
    
    this.elements.statusIndicator.className = 'status-indicator status-disconnected';
    this.elements.statusText.textContent = '连接失败';
  }

  // 显示主界面
  showMainInterface() {
    this.elements.loadingState.style.display = 'none';
    this.elements.disconnectState.style.display = 'none';
    this.elements.mainInterface.style.display = 'flex';
  }

  // 显示通知
  showNotification(message, type = 'info') {
    // 清除已存在的通知，避免重叠显示
    const existingNotifications = document.querySelectorAll('.pm-notification');
    existingNotifications.forEach(notification => notification.remove());
    
    // 创建通知元素
    const notification = document.createElement('div');
    notification.className = 'pm-notification'; // 添加类名用于识别
    
    // 根据类型设置颜色
    let backgroundColor;
    switch (type) {
      case 'success':
        backgroundColor = '#10b981'; // 绿色
        break;
      case 'error':
        backgroundColor = '#ef4444'; // 红色
        break;
      case 'warning':
        backgroundColor = '#f59e0b'; // 橙色
        break;
      default:
        backgroundColor = '#1f2937'; // 深灰色
    }
    
    notification.style.cssText = `
      position: fixed;
      top: 10px;
      left: 50%;
      transform: translateX(-50%);
      background: ${backgroundColor};
      color: white;
      padding: 8px 16px;
      border-radius: 4px;
      z-index: 10000;
      font-size: 12px;
      animation: slideDown 0.3s ease-out;
      box-shadow: 0 2px 8px rgba(0,0,0,0.15);
    `;
    
    notification.textContent = message;
    
    // 添加动画样式
    if (!document.getElementById('notification-styles')) {
      const style = document.createElement('style');
      style.id = 'notification-styles';
      style.textContent = `
        @keyframes slideDown {
          from { transform: translate(-50%, -100%); opacity: 0; }
          to { transform: translate(-50%, 0); opacity: 1; }
        }
      `;
      document.head.appendChild(style);
    }
    
    document.body.appendChild(notification);
    
    // 自动移除
    setTimeout(() => {
      if (notification.parentNode) {
        notification.remove();
      }
    }, 3000);
  }

  // 智能匹配密码算法
  smartMatchPasswords(passwords, currentDomain, currentIP, currentURL) {
    const matchedPasswords = passwords.map(password => {
      const matchResult = this.calculateMatchScore(password, currentDomain, currentIP, currentURL);
      return {
        ...password,
        matchScore: matchResult.score,
        matchType: matchResult.type,
        matchReason: matchResult.reason
      };
    });

    // 按匹配分数排序，分数高的在前
    return matchedPasswords.sort((a, b) => b.matchScore - a.matchScore);
  }

  // 计算匹配分数
  calculateMatchScore(password, currentDomain, currentIP, currentURL) {
    if (!password.website) {
      return { score: 0, type: 'none', reason: '无网站信息' };
    }

    const passwordDomain = this.extractDomain(password.website);
    const passwordIP = this.extractIP(password.website);

    // 完全域名匹配
    if (passwordDomain && currentDomain && passwordDomain === currentDomain) {
      return { score: 100, type: 'exact', reason: '域名完全匹配' };
    }

    // IP地址匹配 - 检查当前域名是否是IP，以及密码域名是否是IP
    const currentIsIP = /^(\d{1,3}\.){3}\d{1,3}$/.test(currentDomain);
    const passwordIsIP = /^(\d{1,3}\.){3}\d{1,3}$/.test(passwordDomain);
    
    if (currentIsIP && passwordIsIP && currentDomain === passwordDomain) {
      return { score: 100, type: 'exact', reason: 'IP地址完全匹配' };
    }
    
    if (passwordIP && currentIP && passwordIP === currentIP) {
      return { score: 95, type: 'exact', reason: 'IP地址匹配' };
    }
    
    // 如果当前页面是IP地址，也检查密码域名提取出的IP
    if (currentIsIP && passwordIP && currentDomain === passwordIP) {
      return { score: 100, type: 'exact', reason: 'IP地址完全匹配' };
    }

    // 子域名匹配
    if (passwordDomain && currentDomain) {
      const passwordParts = passwordDomain.split('.').reverse();
      const currentParts = currentDomain.split('.').reverse();
      
      let matchedParts = 0;
      const minLength = Math.min(passwordParts.length, currentParts.length);
      
      for (let i = 0; i < minLength; i++) {
        if (passwordParts[i] === currentParts[i]) {
          matchedParts++;
        } else {
          break;
        }
      }

      if (matchedParts >= 2) { // 至少匹配顶级域名和二级域名
        const score = 80 - (Math.abs(passwordParts.length - currentParts.length) * 5);
        return { score: Math.max(score, 60), type: 'partial', reason: '子域名匹配' };
      }
    }

    // URL包含匹配
    if (currentURL && password.website) {
      const normalizedPasswordWebsite = password.website.toLowerCase();
      const normalizedCurrentURL = currentURL.toLowerCase();
      
      if (normalizedCurrentURL.includes(normalizedPasswordWebsite) || 
          normalizedPasswordWebsite.includes(normalizedCurrentURL)) {
        return { score: 50, type: 'partial', reason: 'URL包含匹配' };
      }
    }

    // 关键词匹配
    if (password.title && currentDomain) {
      const titleLower = password.title.toLowerCase();
      const domainParts = currentDomain.split('.');
      
      for (const part of domainParts) {
        if (part.length > 3 && titleLower.includes(part)) {
          return { score: 30, type: 'partial', reason: '标题关键词匹配' };
        }
      }
    }

    return { score: 0, type: 'none', reason: '无匹配' };
  }

  // 提取IP地址
  extractIP(url) {
    try {
      if (!url) return null;
      
      let cleanUrl = url.trim();
      
      // 移除协议和路径，只保留主机名
      cleanUrl = cleanUrl.replace(/^https?:\/\//, '').split('/')[0].split('?')[0];
      
      // 移除端口号
      cleanUrl = cleanUrl.split(':')[0];
      
      // 检查是否已经是IP地址
      const ipRegex = /^(\d{1,3}\.){3}\d{1,3}$/;
      if (ipRegex.test(cleanUrl)) {
        return cleanUrl;
      }
      
      // 对于域名，这里无法直接获取IP，返回null
      // 在实际应用中，可能需要通过DNS查询或其他方式获取
      return null;
    } catch (error) {
      return null;
    }
  }



  // 显示当前域名信息
  showCurrentDomainInfo(url, domain, ip) {
    if (!domain && !ip) {
      this.elements.currentDomainInfo.style.display = 'none';
      return;
    }

    let displayText = '';
    if (domain) {
      displayText = domain;
    }
    if (ip && ip !== domain) {
      displayText += ip ? ` (${ip})` : '';
    }

    this.elements.currentDomainValue.textContent = displayText;
    this.elements.currentDomainInfo.style.display = 'block';
  }
}

// 初始化弹窗
document.addEventListener('DOMContentLoaded', () => {
  new PasswordManagerPopup();
}); 
